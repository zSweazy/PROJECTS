<?php
session_start();
require_once 'db_config.php';

if (!isset($_SESSION['student_id'])) {
    header("Location: index.php");
    exit();
}

$studentId = $_SESSION['student_id'];

// Fetch user data
$sql = "SELECT fullname, student_id FROM users WHERE student_id = '$studentId'";
$result = mysqli_query($conn, $sql);
$user = mysqli_fetch_assoc($result);

$studentName = $user['fullname'] ?? "Student";
$displayId = $user['student_id'] ?? $studentId;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Account - Library System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    
    <style>
        :root {
            --admin-navy: #1D3567;
            --bg-light-blue: #DDE6ED;
            --accent-blue: #4B66B0;
        }

        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: var(--bg-light-blue);
        }

        .app-bar {
            background-color: var(--admin-navy);
            color: white;
            padding: 15px 20px;
            display: flex;
            align-items: center;
        }
        .app-bar a { color: white; text-decoration: none; margin-right: 20px; }

        .profile-header {
            background-color: var(--admin-navy);
            color: white;
            text-align: center;
            padding: 20px 0 50px 0;
            border-bottom-left-radius: 30px;
            border-bottom-right-radius: 30px;
        }

        .avatar-circle {
            width: 70px;
            height: 70px;
            background: rgba(255,255,255,0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 10px;
        }

        .container { padding: 20px; max-width: 450px; margin: auto; }

        .qr-card {
            background: white;
            border-radius: 20px;
            padding: 25px;
            text-align: center;
            margin-top: -40px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }

        #qrcode {
            display: flex;
            justify-content: center;
            margin: 20px 0;
        }

        #qrcode img {
            padding: 10px;
            background: white;
            border-radius: 10px;
            border: 1px solid #eee;
        }

        .info-tile {
            background: white;
            padding: 15px;
            border-radius: 12px;
            margin-top: 15px;
            display: flex;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }

        .info-tile i { color: var(--accent-blue); margin-right: 15px; width: 25px; text-align: center; }
        .label { color: gray; font-size: 11px; text-transform: uppercase; display: block; }
        .value { font-weight: bold; color: #333; }
    </style>
</head>
<body>

    <div class="app-bar">
        <a href="student_panel.php"><i class="fas fa-arrow-left"></i></a>
        <h2 style="margin:0; font-size: 18px;">MY ACCOUNT</h2>
    </div>

    <div class="profile-header">
        <div class="avatar-circle"><i class="fas fa-user fa-2x"></i></div>
        <div style="font-weight: bold; text-transform: uppercase;"><?php echo htmlspecialchars($studentName); ?></div>
        <div style="font-size: 12px; opacity: 0.8;">Student ID: <?php echo htmlspecialchars($displayId); ?></div>
    </div>

    <div class="container">
        <div class="qr-card">
            <span style="font-size: 12px; color: #888; font-weight: bold; letter-spacing: 1px;">LIBRARY DIGITAL PASS</span>
            
            <div id="qrcode"></div>

            <div style="font-weight: bold; color: var(--admin-navy);">
                <?php echo htmlspecialchars($displayId); ?>
            </div>
        </div>

        <div class="info-tile">
            <i class="fas fa-id-card"></i>
            <div>
                <span class="label">Full Name</span>
                <span class="value"><?php echo htmlspecialchars($studentName); ?></span>
            </div>
        </div>

        <div class="info-tile">
            <i class="fas fa-hashtag"></i>
            <div>
                <span class="label">Student ID</span>
                <span class="value"><?php echo htmlspecialchars($displayId); ?></span>
            </div>
        </div>

        <div class="info-tile">
            <i class="fas fa-school"></i>
            <div>
                <span class="label">Institution</span>
                <span class="value">Carmen National High School</span>
            </div>
        </div>
    </div>

    <script>
        // Generate QR code locally (no internet needed)
        var qrcode = new QRCode(document.getElementById("qrcode"), {
            text: "<?php echo $displayId; ?>",
            width: 180,
            height: 180,
            colorDark : "#1D3567",
            colorLight : "#ffffff",
            correctLevel : QRCode.CorrectLevel.H
        });
    </script>

</body>
</html>