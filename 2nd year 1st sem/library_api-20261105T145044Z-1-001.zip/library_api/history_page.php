<?php
include 'db_config.php';

// Simulate the admin name (usually handled by your PHP session)
$adminName = "Admin";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction History - Library System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --sidebar-dark: #002147;
            --bg-gray: #F8F9FC;
            --success-green: #2E7D32;
            --primary-blue: #1D3567;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background-color: var(--bg-gray); display: flex; height: 100vh; overflow: hidden; }

        /* Sidebar */
        .sidebar { width: 260px; background: var(--sidebar-dark); color: white; display: flex; flex-direction: column; align-items: center; padding-top: 50px; flex-shrink: 0; }
        .avatar { width: 70px; height: 70px; background: rgba(255,255,255,0.2); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 35px; margin-bottom: 15px; }
        .nav-link { width: 100%; padding: 15px 25px; color: rgba(255,255,255,0.7); text-decoration: none; display: flex; align-items: center; transition: 0.3s; }
        .nav-link i { margin-right: 15px; width: 20px; text-align: center; }
        .nav-link:hover, .nav-link.active { background: rgba(255,255,255,0.1); color: white; }
        .nav-link.active { font-weight: bold; border-left: 4px solid white; }

        /* Content Area */
        .main-content { flex-grow: 1; padding: 40px; overflow-y: auto; }
        .header-row { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 25px; }
        .page-title { color: var(--sidebar-dark); font-size: 24px; font-weight: 800; text-transform: uppercase; }
        .sub-text { color: grey; margin-top: 5px; }

        /* Search Bar */
        .search-box { position: relative; }
        .search-box input { 
            padding: 10px 15px 10px 40px; 
            border-radius: 8px; 
            border: 1px solid #ddd; 
            width: 300px; 
            outline: none;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05); /* Solid shadow for performance */
        }
        .search-box i { position: absolute; left: 15px; top: 12px; color: #aaa; }

        /* Table Container */
        .table-container { 
            background: white; 
            border-radius: 10px; 
            border: 1px solid #eee; /* Using border instead of heavy shadow */
            overflow: hidden;
            width: 100%;
        }

        table { width: 100%; border-collapse: collapse; }
        th { background: var(--primary-blue); color: white; padding: 15px; text-align: left; font-size: 13px; font-weight: 600; text-transform: uppercase; }
        td { padding: 15px; border-bottom: 1px solid #eee; font-size: 14px; color: #333; }
        tr:hover { background-color: #f9f9f9; }
        
        /* Status Badges */
        .badge-returned { 
            background: #E8F5E9; 
            color: var(--success-green); 
            padding: 5px 10px; 
            border-radius: 5px; 
            font-size: 11px; 
            font-weight: bold; 
        }
        .penalty-text { color: #D32F2F; font-weight: 600; }
        .no-records { padding: 40px; text-align: center; color: grey; }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="avatar"><i class="fas fa-user"></i></div>
        <p style="font-weight: bold;"><?php echo strtoupper($adminName); ?></p>
        <p style="font-size: 12px; color: rgba(255,255,255,0.7); margin-bottom: 40px;">Librarian</p>
        
        <a href="admin_dashboard.php" class="nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="inventory.php" class="nav-link"><i class="fas fa-boxes"></i> Inventory</a>
        <a href="transactions.php" class="nav-link"><i class="fas fa-exchange-alt"></i> Transactions</a>
        <a href="reports_page.php" class="nav-link"><i class="fas fa-chart-bar"></i> Reports</a>
        <a href="history_page.php" class="nav-link active"><i class="fas fa-history"></i> History</a>
        
        <div style="flex-grow: 1;"></div>
        <a href="logout.php" class="nav-link" style="color: #ff5252;"><i class="fas fa-sign-out-alt"></i> Log out</a>
    </div>

    <div class="main-content">
        <div class="header-row">
            <div>
                <h1 class="page-title">Transaction History</h1>
                <p class="sub-text">Permanent records of all returned books and collected penalties.</p>
            </div>
            <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" id="historySearch" placeholder="Search ID or Name..." onkeyup="filterTable()">
            </div>
        </div>

        <div class="table-container">
            <table id="historyTable">
                <thead>
                    <tr>
                        <th>TXN ID</th>
                        <th>BORROWER ID</th>
                        <th>NAME</th>
                        <th>BOOK ID</th>
                        <th>RETURNED ON</th>
                        <th>PENALTY PAID</th>
                        <th>STATUS</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Fetch records where status is 'returned'. Use COALESCE to ensure a valid ID shows up.
                    $query = "SELECT *, COALESCE(student_id, user_id, 'N/A') as display_id 
                              FROM transactions 
                              WHERE status = 'returned' 
                              ORDER BY return_date DESC";
                    $result = $conn->query($query);

                    if ($result && $result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            $penaltyVal = floatval($row['penalty'] ?? 0);
                            $penaltyFormatted = number_format($penaltyVal, 2);
                            
                            echo "<tr>";
                            echo "<td>#{$row['id']}</td>";
                            echo "<td><strong>" . htmlspecialchars($row['display_id']) . "</strong></td>";
                            echo "<td>" . htmlspecialchars($row['borrower_name'] ?? 'N/A') . "</td>";
                            echo "<td>" . htmlspecialchars($row['book_id']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['return_date'] ?? 'N/A') . "</td>";
                            
                            // Highlight penalty in red if greater than 0
                            $penaltyClass = ($penaltyVal > 0) ? "penalty-text" : "";
                            echo "<td class='{$penaltyClass}'>₱{$penaltyFormatted}</td>";
                            
                            echo "<td><span class='badge-returned'>RETURNED</span></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='7' class='no-records'>No historical records found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function filterTable() {
            const input = document.getElementById("historySearch");
            const filter = input.value.toLowerCase();
            const table = document.getElementById("historyTable");
            const tr = table.getElementsByTagName("tr");

            // Loop through all table rows, starting from the second (index 1) to skip the header
            for (let i = 1; i < tr.length; i++) {
                const tdId = tr[i].getElementsByTagName("td")[1]; // Borrower ID column
                const tdName = tr[i].getElementsByTagName("td")[2]; // Name column
                
                if (tdId || tdName) {
                    const idValue = tdId.textContent || tdId.innerText;
                    const nameValue = tdName.textContent || tdName.innerText;
                    
                    if (idValue.toLowerCase().indexOf(filter) > -1 || 
                        nameValue.toLowerCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }
    </script>
</body>
</html>