<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction Management - Library System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --admin-navy: #1D3567;
            --sidebar-dark: #002147;
            --bg-gray: #F8F9FC;
            --success-green: #2E7D32;
            --danger-red: #d63031;
            --warning-orange: #f39c12;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background-color: var(--bg-gray); display: flex; height: 100vh; }

        .sidebar { width: 240px; background: var(--sidebar-dark); color: white; display: flex; flex-direction: column; align-items: center; padding-top: 50px; flex-shrink: 0; }
        .user-avatar { width: 70px; height: 70px; background: rgba(255,255,255,0.2); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 35px; margin-bottom: 15px; }
        .nav-link { width: 100%; padding: 15px 25px; color: rgba(255,255,255,0.6); text-decoration: none; display: flex; align-items: center; transition: 0.3s; }
        .nav-link i { margin-right: 15px; width: 20px; }
        .nav-link:hover, .nav-link.active { background: rgba(255,255,255,0.1); color: white; }
        .nav-link.active { border-left: 4px solid white; }

        .content { flex: 1; padding: 40px; overflow-y: auto; }
        .header-title { color: var(--admin-navy); font-size: 24px; font-weight: 800; margin-bottom: 25px; text-transform: uppercase; }

        /* Alerts */
        .alert { padding: 15px; border-radius: 8px; margin-bottom: 20px; font-weight: 600; display: none; }
        .alert-success { background: #E8F5E9; color: var(--success-green); border: 1px solid #C8E6C9; }
        .alert-warning { background: #FFF3E0; color: #E65100; border: 1px solid #FFE0B2; }

        .card { background: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); margin-bottom: 30px; }
        .form-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; }
        .input-group { display: flex; flex-direction: column; }
        .input-group label { font-size: 12px; font-weight: 700; color: #666; margin-bottom: 5px; }
        .input-group input { padding: 12px; border: 1px solid #ddd; border-radius: 8px; outline: none; }
        .btn-add { background: var(--admin-navy); color: white; border: none; padding: 12px 30px; border-radius: 50px; font-weight: 700; cursor: pointer; margin-top: 20px; display: inline-flex; align-items: center; gap: 10px; }
        .btn-cancel { background: #eee; color: #333; margin-left: 10px; display: none; border: none; padding: 12px 30px; border-radius: 50px; font-weight: 700; cursor: pointer; }

        .table-container { background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 10px rgba(0,0,0,0.05); }
        .table-header { padding: 20px; display: flex; justify-content: space-between; align-items: center; }
        table { width: 100%; border-collapse: collapse; }
        th { background: var(--admin-navy); color: white; padding: 15px; text-align: left; font-size: 13px; }
        td { padding: 15px; border-bottom: 1px solid #eee; font-size: 14px; color: #444; }
        
        .action-btns { display: flex; gap: 5px; }
        .badge-btn { border: none; padding: 6px 12px; border-radius: 6px; font-size: 11px; font-weight: 700; cursor: pointer; transition: 0.2s; }
        .btn-return { background: #E3F2FD; color: #1976D2; }
        .btn-return:hover { background: #1976D2; color: white; }
        .btn-penalty { background: #ffeaa7; color: #d35400; }
        .btn-penalty:hover { background: #fab1a0; color: #c0392b; }
        .btn-edit { background: #f1f2f6; color: #2f3542; }
        .btn-edit:hover { background: #dfe4ea; }
        
        .search-box { padding: 10px 15px; border: 1px solid #ddd; border-radius: 8px; width: 300px; }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="user-avatar"><i class="fas fa-user"></i></div>
        <p style="margin-bottom: 30px; font-weight: 700;">ADMIN</p>
        <a href="admin_dashboard.php" class="nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="inventory.php" class="nav-link"><i class="fas fa-boxes"></i> Inventory</a>
        <a href="transactions.php" class="nav-link active"><i class="fas fa-exchange-alt"></i> Transactions</a>
        <a href="reports_page.php" class="nav-link"><i class="fas fa-chart-bar"></i> Reports</a>
        <a href="history_page.php" class="nav-link"><i class="fas fa-history"></i> History</a>
        <div style="flex-grow: 1;"></div>
        <a href="logout.php" class="nav-link" style="color: #ff7675;"><i class="fas fa-sign-out-alt"></i> Log out</a>
    </div>

    <div class="content">
        <h1 class="header-title">Transaction Management</h1>

        <div id="statusAlert" class="alert">
            <i id="alertIcon" class="fas fa-check-circle"></i> <span id="alertMsg"></span>
        </div>

        <div class="card">
            <form id="txnForm">
                <input type="hidden" id="edit_id" name="edit_id">
                <div class="form-row">
                    <div class="input-group">
                        <label>Student ID</label>
                        <input type="text" id="student_id" name="student_id" placeholder="Ex: 2024-001" required>
                    </div>
                    <div class="input-group">
                        <label>Borrower Name</label>
                        <input type="text" id="borrower_name" name="borrower_name" placeholder="Full Name" required>
                    </div>
                    <div class="input-group">
                        <label>Book ID (Check Inventory First)</label>
                        <input type="number" id="book_id" name="book_id" placeholder="Book ID" required>
                    </div>
                    <div class="input-group">
                        <label>Due Date</label>
                        <input type="date" id="due_date" name="due_date" required>
                    </div>
                </div>
                <div style="display: flex; align-items: center;">
                    <button type="submit" id="submitBtn" class="btn-add">
                        <i class="fas fa-plus"></i> <span id="btnText">ADD TRANSACTION</span>
                    </button>
                    <button type="button" id="cancelEdit" class="btn-cancel" onclick="resetForm()">CANCEL</button>
                </div>
            </form>
        </div>

        <div class="table-container">
            <div class="table-header">
                <h3 style="font-size: 18px; color: #333;">ACTIVE BORROWERS</h3>
                <input type="text" id="search" class="search-box" placeholder="Search Student ID or Name..." onkeyup="filterTable()">
            </div>
            <table id="txnTable">
                <thead>
                    <tr>
                        <th>TXN ID</th>
                        <th>STUDENT ID</th>
                        <th>NAME</th>
                        <th>BOOK ID</th>
                        <th>BORROWED</th>
                        <th>DUE DATE</th>
                        <th>ACTION</th>
                    </tr>
                </thead>
                <tbody id="tableBody"></tbody>
            </table>
        </div>
    </div>

    <script>
        const apiUrl = 'transactions_api.php';

        document.addEventListener('DOMContentLoaded', fetchTransactions);

        async function fetchTransactions() {
            try {
                const response = await fetch(apiUrl + '?type=active');
                const data = await response.json();
                renderTable(data);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        }

        function calculatePenalty(dueDateStr) {
            const dueDate = new Date(dueDateStr);
            const today = new Date();
            today.setHours(0, 0, 0, 0); 
            dueDate.setHours(0, 0, 0, 0);

            if (today > dueDate) {
                const diffTime = Math.abs(today - dueDate);
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                return diffDays * 5;
            }
            return 0;
        }

        function renderTable(transactions) {
            const tbody = document.getElementById('tableBody');
            if (!transactions || transactions.length === 0) {
                tbody.innerHTML = '<tr><td colspan="7" style="text-align:center; padding: 30px; color: #999;">No active transactions found.</td></tr>';
                return;
            }

            tbody.innerHTML = transactions.map(t => {
                const penalty = calculatePenalty(t.due_date);
                const isOverdue = penalty > 0;
                
                return `
                    <tr>
                        <td>#${t.id}</td>
                        <td><strong>${t.student_id}</strong></td>
                        <td>${t.borrower_name || 'N/A'}</td>
                        <td>${t.book_id}</td>
                        <td>${t.borrow_date}</td>
                        <td>${t.due_date}</td>
                        <td class="action-btns">
                            <button class="badge-btn ${isOverdue ? 'btn-penalty' : 'btn-return'}" 
                                onclick="processReturn(${t.id}, ${penalty})">
                                ${isOverdue ? `Paid? (₱${penalty})` : 'Return'}
                            </button>
                            <button class="badge-btn btn-edit" onclick='prepareEdit(${JSON.stringify(t)})'>
                                <i class="fas fa-edit"></i> Edit
                            </button>
                        </td>
                    </tr>
                `;
            }).join('');
        }

        document.getElementById('txnForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const editId = document.getElementById('edit_id').value;
            const formData = new FormData(e.target);
            formData.append('action', editId ? 'update' : 'add');
            if(editId) formData.append('id', editId);

            try {
                const res = await fetch(apiUrl, { method: 'POST', body: formData });
                const result = await res.json();
                
                if (result.status === 'success') {
                    showAlert(editId ? "Transaction updated!" : "Transaction added!", "success");
                    resetForm();
                    fetchTransactions();
                } else if (result.status === 'warning') {
                    showAlert(result.message, "warning");
                } else {
                    showAlert(result.message || "Error occurred", "warning");
                }
            } catch (err) { showAlert("Server connection failed", "warning"); }
        });

        async function processReturn(id, penalty) {
            let confirmMsg = penalty > 0 
                ? `OVERDUE: Penalty is ₱${penalty}.00. Has the borrower paid the fine?` 
                : 'Confirm book return?';

            if (!confirm(confirmMsg)) return;

            const formData = new FormData();
            formData.append('action', 'return');
            formData.append('id', id);
            formData.append('penalty_amount', penalty);

            try {
                const res = await fetch(apiUrl, { method: 'POST', body: formData });
                const result = await res.json();
                if (result.status === 'success') {
                    showAlert("Book returned and inventory updated!", "success");
                    fetchTransactions();
                } else {
                    showAlert("Return failed: " + result.message, "warning");
                }
            } catch (err) { showAlert("Server error during return", "warning"); }
        }

        function prepareEdit(txn) {
            document.getElementById('edit_id').value = txn.id;
            document.getElementById('student_id').value = txn.student_id;
            document.getElementById('borrower_name').value = txn.borrower_name;
            document.getElementById('book_id').value = txn.book_id;
            document.getElementById('due_date').value = txn.due_date;
            
            document.getElementById('btnText').innerText = "UPDATE TRANSACTION";
            document.getElementById('submitBtn').style.background = "#2f3542";
            document.getElementById('cancelEdit').style.display = "inline-flex";
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        function resetForm() {
            document.getElementById('txnForm').reset();
            document.getElementById('edit_id').value = "";
            document.getElementById('btnText').innerText = "ADD TRANSACTION";
            document.getElementById('submitBtn').style.background = "var(--admin-navy)";
            document.getElementById('cancelEdit').style.display = "none";
        }

        function showAlert(msg, type) {
            const alertDiv = document.getElementById('statusAlert');
            const alertMsg = document.getElementById('alertMsg');
            const alertIcon = document.getElementById('alertIcon');
            
            alertDiv.className = `alert alert-${type}`;
            alertIcon.className = type === 'success' ? 'fas fa-check-circle' : 'fas fa-exclamation-triangle';
            alertMsg.innerText = msg;
            alertDiv.style.display = 'block';
            
            setTimeout(() => alertDiv.style.display = 'none', 4000);
        }

        function filterTable() {
            let input = document.getElementById('search').value.toUpperCase();
            let rows = document.getElementById('tableBody').getElementsByTagName('tr');
            for (let i = 0; i < rows.length; i++) {
                let text = rows[i].textContent.toUpperCase();
                rows[i].style.display = text.includes(input) ? "" : "none";
            }
        }
    </script>
</body>
</html>