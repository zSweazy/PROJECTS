<?php
session_start();
require_once 'db_config.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $typedId = mysqli_real_escape_string($conn, $_POST['student_id']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $sql = "SELECT * FROM users WHERE student_id = '$typedId' AND password = '$password' LIMIT 1";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        $_SESSION['fullname'] = $user['fullname'];
        $_SESSION['student_id'] = $user['student_id'];
        $_SESSION['role'] = $user['role'];

        if ($user['role'] == 'admin') {
            header("Location: admin_dashboard.php");
        } else {
            header("Location: student_panel.php?fullname=" . urlencode($user['fullname']) . "&student_id=" . $user['student_id']);
        }
        exit();
    } else {
        echo "<script>alert('Invalid Student ID or Password');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --admin-navy: #1D3567;
            --bg-color: #DDE6ED;
            --outline-blue: #a3c1da; /* The blue color from your image */
        }

        body {
            margin: 0;
            font-family: 'Segoe UI', Roboto, sans-serif;
            background-color: var(--bg-color);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .login-card {
            width: 400px;
            background: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            text-align: center;
            box-sizing: border-box;
        }

        /* --- Flutter-style Animations --- */
        @keyframes flutterSlideUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animated-item {
            opacity: 0;
            animation: flutterSlideUp 0.8s cubic-bezier(0.215, 0.61, 0.355, 1) forwards;
        }
        .delay-0 { animation-delay: 0.4s; }
        .delay-1 { animation-delay: 0.55s; }
        .delay-2 { animation-delay: 0.7s; }
        .delay-3 { animation-delay: 0.85s; }
        .delay-4 { animation-delay: 1.0s; }
        .delay-5 { animation-delay: 1.15s; }
        .delay-6 { animation-delay: 1.3s; }

        /* --- Floating Label CSS --- */
        .input-field {
            position: relative;
            margin-top: 25px;
            text-align: left;
        }

        input {
            width: 100%;
            padding: 15px 12px;
            border: 1px solid #BDBDBD;
            border-radius: 6px;
            font-size: 16px;
            box-sizing: border-box;
            outline: none;
            background: transparent;
            transition: border-color 0.2s;
        }

        /* Label styling (Floating Label) */
        .input-field label {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            background: white;
            padding: 0 5px;
            color: #757575;
            font-size: 16px;
            pointer-events: none;
            transition: 0.2s ease all;
        }

        /* Float the label up when focused or input has text */
        input:focus + label,
        input:not(:placeholder-shown) + label {
            top: 0;
            font-size: 12px;
            color: var(--outline-blue);
        }

        /* Change border color on focus */
        input:focus {
            border: 1.5px solid var(--outline-blue);
        }

        .suffix-icon {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #757575;
        }

        /* Other UI bits */
        .logo-container { height: 100px; display: flex; justify-content: center; align-items: center; margin-bottom: 10px; }
        .logo-container img { height: 100px; object-fit: contain; }
        .title { font-size: 22px; font-weight: bold; letter-spacing: 4px; color: var(--admin-navy); margin-top: 10px; }
        .forgot-btn-container { text-align: right; margin-top: 5px; }
        .forgot-btn-container a { color: var(--admin-navy); font-size: 13px; text-decoration: none; font-weight: 500; }
        .login-btn { background-color: var(--admin-navy); color: white; border: none; width: 100%; height: 55px; border-radius: 8px; font-size: 16px; cursor: pointer; margin-top: 25px; transition: opacity 0.2s; }
        .login-btn:hover { opacity: 0.9; }
        .footer-text { margin-top: 20px; font-size: 14px; }
        .footer-text a { color: var(--admin-navy); font-weight: bold; text-decoration: none; }
    </style>
</head>
<body>

<div class="login-card">
    <form method="POST" autocomplete="off">
        <div class="animated-item delay-0 logo-container">
            <img src="image/logo.png" alt="Library Logo">
        </div>

        <div class="animated-item delay-1">
            <div class="title">LIBRARY</div>
        </div>

        <div class="animated-item delay-2 input-field" style="margin-top: 40px;">
            <input type="text" name="student_id" id="student_id" placeholder=" " required>
            <label for="student_id">Student ID</label>
        </div>

        <div class="animated-item delay-3 input-field">
            <input type="password" id="password" name="password" placeholder=" " required>
            <label for="password">Password</label>
            <i class="fas fa-eye-slash suffix-icon" id="togglePassword"></i>
        </div>

        <div class="animated-item delay-4 forgot-btn-container">
            <a href="forgot_password.php">Forgot Password?</a>
        </div>

        <div class="animated-item delay-5">
            <button type="submit" class="login-btn">Log in</button>
        </div>

        <div class="animated-item delay-6 footer-text">
            New to the library? <a href="signup.php">Create Account</a>
        </div>
    </form>
</div>

<script>
    const togglePassword = document.querySelector('#togglePassword');
    const password = document.querySelector('#password');

    togglePassword.addEventListener('click', function () {
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);
        this.classList.toggle('fa-eye');
        this.classList.toggle('fa-eye-slash');
    });
</script>

</body>
</html>