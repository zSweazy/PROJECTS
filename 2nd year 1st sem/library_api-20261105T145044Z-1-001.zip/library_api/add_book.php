<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, PUT, DELETE, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header('Content-Type: application/json; charset=UTF-8');

include 'db_config.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// --- FETCH BOOKS (GET) ---
if ($method === 'GET') {
    $show_archived = (isset($_GET['archived']) && $_GET['archived'] == '1') ? 1 : 0;
    
    if ($show_archived) {
        // Show books manually archived OR those that ran out of stock (0 copies)
        $sql = "SELECT * FROM books WHERE is_archived = 1 OR copies <= 0 ORDER BY id DESC";
    } else {
        // Only show active books that have stock available
        $sql = "SELECT * FROM books WHERE is_archived = 0 AND copies > 0 ORDER BY id DESC";
    }

    $result = $conn->query($sql);
    $books = [];
    while($row = $result->fetch_assoc()) {
        $books[] = $row;
    }
    echo json_encode($books);

// --- ADD NEW BOOK (POST) ---
} elseif ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    if (!$data) exit;

    $title   = $data['title'];
    $author  = $data['author'];
    $genre   = $data['genre'];
    $subject = $data['subject'];
    $grade   = $data['grade'];
    $copies  = (int)$data['copies'];

    // Auto-archive logic: if added with 0 copies, it goes straight to the archive
    $is_archived = ($copies <= 0) ? 1 : 0;

    $sql = "INSERT INTO books (title, author, genre, subject, grade, copies, status, is_archived) VALUES (?, ?, ?, ?, ?, ?, 'available', ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssii", $title, $author, $genre, $subject, $grade, $copies, $is_archived);
    
    if($stmt->execute()) {
        echo json_encode(["success" => true, "message" => "Book added successfully!"]);
    } else {
        echo json_encode(["success" => false, "message" => $conn->error]);
    }

// --- UPDATE BOOK (PUT) ---
// This handles the "Auto-Restore" when you edit a 0-copy book and add stock
} elseif ($method === 'PUT') {
    $data = json_decode(file_get_contents("php://input"), true);
    if (!$data) exit;

    $id      = $data['id'];
    $title   = $data['title'];
    $author  = $data['author'];
    $genre   = $data['genre'];
    $subject = $data['subject'];
    $grade   = $data['grade'];
    $copies  = (int)$data['copies'];

    // AUTO-RESTORE LOGIC: 
    // If copies are updated to 1 or more, set is_archived to 0 (Active)
    // If copies remain 0, it stays as 1 (Archived)
    $is_archived = ($copies <= 0) ? 1 : 0;

    $sql = "UPDATE books SET title=?, author=?, genre=?, subject=?, grade=?, copies=?, is_archived=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssiii", $title, $author, $genre, $subject, $grade, $copies, $is_archived, $id);
    
    if($stmt->execute()) {
        echo json_encode([
            "success" => true, 
            "message" => ($is_archived == 0) ? "Book restored to inventory!" : "Book updated successfully!"
        ]);
    } else {
        echo json_encode(["success" => false, "message" => $conn->error]);
    }

// --- DELETE BOOK (DELETE) ---
} elseif ($method === 'DELETE') {
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $stmt = $conn->prepare("DELETE FROM books WHERE id = ?");
        $stmt->bind_param("i", $id);
        
        if($stmt->execute()) {
            echo json_encode(["success" => true]);
        } else {
            echo json_encode(["success" => false, "message" => $conn->error]);
        }
    }
}
?>