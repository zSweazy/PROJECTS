<?php
$host = "127.0.0.1";
$user = "root";
$pass = ""; 
$dbname = "library_db";

// 1. Initial connection
$conn = new mysqli($host, $user, $pass);

if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Connection failed: " . $conn->connect_error]));
}

// 2. Create and Select DB
$conn->query("CREATE DATABASE IF NOT EXISTS $dbname");
$conn->select_db($dbname);
$conn->set_charset("utf8mb4");

// 3. Ensure 'books' table exists
$tableQuery = "CREATE TABLE IF NOT EXISTS books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255),
    genre VARCHAR(100),
    subject VARCHAR(100),
    grade VARCHAR(50),
    copies INT DEFAULT 0,
    image_url VARCHAR(255),
    status VARCHAR(50) DEFAULT 'available',
    is_archived TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
$conn->query($tableQuery);
$conn->query("ALTER TABLE books ADD COLUMN IF NOT EXISTS is_archived TINYINT(1) DEFAULT 0");

// 4. Ensure 'system_logs' table exists
$conn->query("CREATE TABLE IF NOT EXISTS system_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    action_details TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// 5. GLOBAL LOGGING FUNCTION
// Use this anywhere in your app like: logActivity($conn, "Deleted book ID 5");
if (!function_exists('logActivity')) {
    function logActivity($conn, $msg) {
        $stmt = $conn->prepare("INSERT INTO system_logs (action_details) VALUES (?)");
        $stmt->bind_param("s", $msg);
        $stmt->execute();
        $stmt->close();
    }
}
?>