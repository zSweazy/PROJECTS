<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Accept");
header("Content-Type: application/json");

// Handle preflight OPTIONS request for Flutter Web
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit;
}

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "library_db"; // Confirmed from your SQL file

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed"]);
    exit;
}

// Get JSON input from Flutter
$data = json_decode(file_get_contents("php://input"), true);

if (isset($data['student_id'], $data['old_password'], $data['new_password'])) {
    $student_id = $data['student_id'];
    $old_password = $data['old_password'];
    $new_password = $data['new_password'];

    // 1. Fetch the user
    $stmt = $conn->prepare("SELECT password FROM users WHERE student_id = ?");
    $stmt->bind_param("s", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($user = $result->fetch_assoc()) {
        $db_password = $user['password'];

        // 2. Verify Password 
        // NOTE: Since your DB currently has plain text "jayalastra", 
        // we check BOTH plain text and hash for compatibility.
        if ($old_password === $db_password || password_verify($old_password, $db_password)) {
            
            // 3. Hash the NEW password before saving (Best Practice)
            $hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);
            
            $update_stmt = $conn->prepare("UPDATE users SET password = ? WHERE student_id = ?");
            $update_stmt->bind_param("ss", $hashed_new_password, $student_id);
            
            if ($update_stmt->execute()) {
                echo json_encode(["status" => "success", "message" => "Password updated!"]);
            } else {
                echo json_encode(["status" => "error", "message" => "Failed to update database"]);
            }
        } else {
            echo json_encode(["status" => "error", "message" => "Incorrect old password"]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Student ID not found"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid input"]);
}

$conn->close();
?>