<?php
include 'db_config.php';

// 1. Fetching counts for Stat Cards
$booksCount = $conn->query("SELECT COUNT(*) as total FROM books WHERE is_archived = 0")->fetch_assoc()['total'];
$usersCount = $conn->query("SELECT COUNT(*) as total FROM users")->fetch_assoc()['total'];
$loansCount = $conn->query("SELECT COUNT(*) as total FROM transactions WHERE status = 'borrowed'")->fetch_assoc()['total'];

// 2. Fetch Recent Logs for both Web and API
$logsResult = $conn->query("SELECT student_name, student_id, action, log_time FROM system_logs ORDER BY log_time DESC LIMIT 10");

$activities = [];
if ($logsResult) {
    while($row = $logsResult->fetch_assoc()) {
        $activities[] = [
            'student_name' => $row['student_name'],
            'student_id'   => $row['student_id'],
            'action'       => strtoupper($row['action']),
            'time'         => date('M d, h:i A', strtotime($row['log_time']))
        ];
    }
}

// --- API DETECTION: If Flutter/Dart or JS fetch calls this, return JSON and exit ---
if (isset($_GET['api']) || (isset($_SERVER['HTTP_USER_AGENT']) && strpos($_SERVER['HTTP_USER_AGENT'], 'Dart') !== false)) {
    header('Content-Type: application/json');
    echo json_encode([
        'total_users' => (int)$usersCount,
        'total_books' => (int)$booksCount,
        'total_overdue' => (int)$loansCount,
        'activities' => $activities
    ]);
    exit;
}

$adminName = "ADMIN"; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carmen National High School - Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://unpkg.com/html5-qrcode"></script>
    
    <style>
        :root {
            --primary-blue: #1D3567;
            --sidebar-dark: #002147;
            --bg-light: #F8F9FC;
            --accent-blue: #4E73DF;
            --border-light: rgba(0,0,0,0.12);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { display: flex; background-color: var(--bg-light); height: 100vh; overflow: hidden; }

        /* --- SIDEBAR --- */
        .sidebar { width: 240px; background-color: var(--sidebar-dark); color: white; display: flex; flex-direction: column; align-items: center; padding-top: 50px; flex-shrink: 0; }
        .avatar-circle { width: 70px; height: 70px; background-color: rgba(255,255,255,0.24); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 15px; }
        .admin-name { font-weight: bold; text-transform: uppercase; margin-bottom: 5px; letter-spacing: 1px; }
        .admin-role { color: rgba(255,255,255,0.7); font-size: 12px; margin-bottom: 40px; }
        .nav-item { width: 100%; padding: 15px 25px; display: flex; align-items: center; color: rgba(255,255,255,0.54); text-decoration: none; transition: 0.2s; font-size: 14px; }
        .nav-item i { width: 25px; margin-right: 15px; font-size: 18px; }
        .nav-item.active { background-color: rgba(255,255,255,0.1); color: white; border-left: 4px solid white; }
        .nav-item:hover { color: white; background: rgba(255,255,255,0.05); }
        .nav-item.logout { margin-top: auto; color: #ff5252; margin-bottom: 20px; }

        /* --- MAIN CONTENT --- */
        .main-content { flex: 1; padding: 20px 30px; overflow-y: auto; }
        .school-header { font-size: 22px; font-weight: bold; color: var(--primary-blue); margin-bottom: 25px; }

        /* --- STAT CARDS --- */
        .stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: white; padding: 20px; border-radius: 8px; border: 1px solid var(--border-light); display: flex; align-items: center; justify-content: space-between; border-left: 5px solid var(--accent-blue); }
        .stat-card.books { border-left-color: #1cc88a; } 
        .stat-card.loans { border-left-color: #f6c23e; }
        .stat-card i { font-size: 28px; color: #dddfeb; }
        .stat-info h3 { font-size: 24px; color: #5a5c69; }
        .stat-info p { font-size: 11px; color: var(--accent-blue); text-transform: uppercase; font-weight: bold; margin-bottom: 5px; }

        /* --- SCANNER CARD --- */
        .btn-scan { background-color: var(--primary-blue); color: white; border: none; padding: 12px 25px; border-radius: 8px; cursor: pointer; font-weight: bold; display: flex; align-items: center; gap: 8px; margin-bottom: 20px; }
        #scanner-container { display: none; background: white; padding: 20px; border-radius: 8px; border: 1px solid var(--border-light); margin-bottom: 20px; text-align: center; max-width: 440px; }
        #reader { width: 100%; border-radius: 8px; overflow: hidden; border: 1px solid #ddd; }

        /* --- LOGS TABLE --- */
        .table-container { background: white; border-radius: 8px; border: 1px solid var(--border-light); overflow: hidden; }
        .table-title { padding: 15px 20px; font-weight: bold; color: var(--primary-blue); border-bottom: 1px solid #eee; }
        table { width: 100%; border-collapse: collapse; }
        thead th { background-color: var(--primary-blue); color: white; text-align: left; padding: 12px 20px; font-size: 12px; text-transform: uppercase; }
        tbody td { padding: 12px 20px; border-bottom: 1px solid #eee; font-size: 14px; color: #333; }
        .badge { background: #e3f2fd; color: #2196f3; padding: 4px 10px; border-radius: 4px; font-size: 11px; font-weight: bold; text-transform: uppercase; }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="avatar-circle"><i class="fas fa-user fa-2x"></i></div>
        <div class="admin-name"><?php echo $adminName; ?></div>
        <div class="admin-role">Librarian</div>

        <a href="admin_dashboard.php" class="nav-item active"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="inventory.php" class="nav-item"><i class="fas fa-box"></i> Inventory</a>
        <a href="transactions.php" class="nav-item"><i class="fas fa-exchange-alt"></i> Transactions</a>
        <a href="reports_page.php" class="nav-item"><i class="fas fa-chart-bar"></i> Reports</a>
        <a href="history_page.php" class="nav-item"><i class="fas fa-history"></i> History</a>
        
        <a href="index.php" class="nav-item logout"><i class="fas fa-sign-out-alt"></i> Log out</a>
    </div>

    <div class="main-content">
        <div class="school-header">CARMEN NATIONAL HIGH SCHOOL</div>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-info"><p>Total Users</p><h3 id="stat-users"><?php echo $usersCount; ?></h3></div>
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-card books">
                <div class="stat-info"><p>Total Books</p><h3 id="stat-books"><?php echo $booksCount; ?></h3></div>
                <i class="fas fa-book"></i>
            </div>
            <div class="stat-card loans">
                <div class="stat-info"><p>Active Loans</p><h3 id="stat-loans"><?php echo $loansCount; ?></h3></div>
                <i class="fas fa-bookmark"></i>
            </div>
        </div>

        <button class="btn-scan" onclick="toggleScanner()">
            <i class="fas fa-qrcode"></i> Open Attendance Scanner
        </button>

        <div id="scanner-container">
            <div id="reader"></div>
            <button onclick="toggleScanner()" style="margin-top:15px; color:red; border:none; background:none; cursor:pointer; font-weight:600;">
                <i class="fas fa-times-circle"></i> Close Scanner
            </button>
        </div>

        <div class="table-container">
            <div class="table-title">RECENT SYSTEM LOGS</div>
            <table>
                <thead>
                    <tr>
                        <th>Student Name</th>
                        <th>Student ID</th>
                        <th>Action</th>
                        <th>Time</th>
                    </tr>
                </thead>
                <tbody id="logsTableBody">
                    <?php if (!empty($activities)): ?>
                        <?php foreach($activities as $log): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($log['student_name']); ?></strong></td>
                            <td><?php echo $log['student_id']; ?></td>
                            <td><span class="badge"><?php echo $log['action']; ?></span></td>
                            <td><?php echo $log['time']; ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="4" style="text-align:center; padding:30px; color:#999;">No recent activity found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
    // --- 1. QR SCANNER LOGIC ---
    let html5QrCode;
    let isScanning = false;
    const beep = new Audio("data:audio/wav;base64,UklGRl9vT19XQVZFRm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YTtvT18=");

    function toggleScanner() {
        const con = document.getElementById('scanner-container');
        if (con.style.display === 'none' || !con.style.display) {
            con.style.display = 'block';
            startScanner();
        } else {
            stopScanner();
            con.style.display = 'none';
        }
    }

    function startScanner() {
        html5QrCode = new Html5Qrcode("reader");
        html5QrCode.start(
            { facingMode: "environment" }, 
            { fps: 10, qrbox: { width: 250, height: 250 } }, 
            (decodedText) => {
                if (isScanning) return;
                isScanning = true;
                beep.play();
                processScan(decodedText);
                stopScanner();
                document.getElementById('scanner-container').style.display = 'none';
            }
        ).catch(err => console.error(err));
    }

    function stopScanner() {
        if(html5QrCode) {
            html5QrCode.stop().then(() => { isScanning = false; }).catch(err => {});
        }
    }

    function processScan(id) {
        fetch('log_arrival.php?student_id=' + encodeURIComponent(id))
        .then(res => res.json())
        .then(data => {
            if(data.success) {
                // Instantly refresh the data instead of a full reload
                fetchRecentLogs();
            } else {
                alert("Error: " + data.message);
                isScanning = false;
            }
        }).catch(err => {
            console.error(err);
            isScanning = false;
        });
    }

    // --- 2. LIVE SYNC LOGIC (MERGED) ---
    async function fetchRecentLogs() {
        try {
            // Call this same PHP file with ?api=true to get JSON data
            const response = await fetch('admin_dashboard.php?api=true');
            const data = await response.json();

            if (data) {
                // Update Stat Cards
                document.getElementById('stat-users').innerText = data.total_users;
                document.getElementById('stat-books').innerText = data.total_books;
                document.getElementById('stat-loans').innerText = data.total_overdue;

                // Update Logs Table
                if (data.activities) {
                    updateLogsTable(data.activities);
                }
            }
        } catch (error) {
            console.error("Sync Error:", error);
        }
    }

    function updateLogsTable(activities) {
        const tableBody = document.getElementById("logsTableBody");
        if (!tableBody) return;

        if (activities.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="4" style="text-align:center; padding:30px; color:#999;">No recent activity found.</td></tr>';
            return;
        }

        let rows = "";
        activities.forEach(log => {
            rows += `
                <tr>
                    <td><strong>${log.student_name}</strong></td>
                    <td>${log.student_id}</td>
                    <td><span class="badge">${log.action}</span></td>
                    <td>${log.time}</td>
                </tr>
            `;
        });
        tableBody.innerHTML = rows;
    }

    // Set to auto-sync every 5 seconds
    setInterval(fetchRecentLogs, 5000);
    </script>
</body>
</html>