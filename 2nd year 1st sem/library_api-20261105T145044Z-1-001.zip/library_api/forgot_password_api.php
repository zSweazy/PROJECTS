<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include 'db_config.php'; 
error_reporting(0);

// Handle preflight OPTIONS request for Flutter Web
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Read input (handles both Flutter's JSON and Web's Form data)
$jsonInput = json_decode(file_get_contents('php://input'), true);
$action = $_GET['action'] ?? $jsonInput['action'] ?? $_POST['action'] ?? '';

if ($action == 'get_question') {
    $id = $_GET['id'] ?? $jsonInput['id'] ?? $_POST['id'] ?? '';
    
    $stmt = $conn->prepare("SELECT security_question FROM users WHERE student_id = ?");
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        echo json_encode(["success" => true, "question" => $row['security_question']]);
    } else {
        echo json_encode(["success" => false, "message" => "Student ID not found"]);
    }
    $stmt->close();
    exit;
}

if ($action == 'reset_password') {
    $id = $jsonInput['id'] ?? $_POST['id'] ?? '';
    $answer = $jsonInput['answer'] ?? $_POST['answer'] ?? '';
    $new_pass = $jsonInput['new_password'] ?? $_POST['new_password'] ?? '';

    $stmt = $conn->prepare("SELECT security_answer FROM users WHERE student_id = ?");
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && trim(strtolower($user['security_answer'])) === trim(strtolower($answer))) {
        $update = $conn->prepare("UPDATE users SET password = ? WHERE student_id = ?");
        $update->bind_param("ss", $new_pass, $id);
        if ($update->execute()) {
            echo json_encode(["success" => true, "message" => "Password updated successfully"]);
        } else {
            echo json_encode(["success" => false, "message" => "Database update failed"]);
        }
    } else {
        echo json_encode(["success" => false, "message" => "Incorrect security answer"]);
    }
    $stmt->close();
    exit;
}

// If no action matched, show what was received for debugging
echo json_encode([
    "success" => false, 
    "message" => "Invalid action", 
    "received_action" => $action
]);
?>