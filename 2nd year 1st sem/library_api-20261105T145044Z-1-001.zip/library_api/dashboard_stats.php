<?php
header('Content-Type: application/json');
include 'db_connection.php';

$response = [];

try {
    // total student users
    $user_res = $conn->query("SELECT COUNT(*) as total FROM users WHERE role = 'student'");
    $response['total_users'] = $user_res->fetch_assoc()['total'] ?? 0;

    // total books
    $book_res = $conn->query("SELECT COUNT(*) as total FROM books");
    $response['total_books'] = $book_res->fetch_assoc()['total'] ?? 0;

    // overdue books
    $current_time = date('Y-m-d H:i:s');
    $overdue_res = $conn->query("SELECT COUNT(*) as total FROM books WHERE status = 'borrowed' AND due_date < '$current_time'");
    $response['total_overdue'] = $overdue_res->fetch_assoc()['total'] ?? 0;

    // recent activities
    $activities = [];
    $act_res = $conn->query("SELECT username, action_text, created_at FROM activity_logs ORDER BY created_at DESC LIMIT 5");
    while($row = $act_res->fetch_assoc()) {
        $activities[] = [
            "text" => "User '" . $row['username'] . "' " . $row['action_text'],
            "time" => date('M d, h:i A', strtotime($row['created_at']))
        ];
    }
    $response['activities'] = $activities;
    $response['success'] = true;

} catch (Exception $e) {
    $response['success'] = false;
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>