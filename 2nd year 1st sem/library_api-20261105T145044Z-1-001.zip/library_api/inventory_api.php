<?php
// 1. UNIVERSAL CONNECTION HEADERS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, PUT, DELETE, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header('Content-Type: application/json; charset=UTF-8');

// Buffer output to catch potential PHP notices that break JSON
ob_start();
include 'db_config.php';

$method = $_SERVER['REQUEST_METHOD'];

// Handle Preflight requests
if ($method === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// -------------------------------------------------------------------------
// --- FETCH BOOKS OR TRANSACTIONS (GET) ---
// -------------------------------------------------------------------------
if ($method === 'GET') {
    // Check if we are fetching transactions or books
    $type = $_GET['type'] ?? 'books'; 

    if ($type === 'transactions') {
        $view = $_GET['view'] ?? 'active';
        if ($view === 'history') {
            $sql = "SELECT * FROM transactions WHERE status = 'returned' ORDER BY return_date DESC";
        } else {
            $sql = "SELECT * FROM transactions WHERE status IN ('active', 'overdue', '', NULL) ORDER BY id DESC";
        }
    } else {
        // Default: Fetch Books
        $show_archived = (isset($_GET['archived']) && $_GET['archived'] == '1') ? 1 : 0;
        $search = isset($_GET['search']) ? "%" . $_GET['search'] . "%" : null;

        if ($search) {
            $sql = "SELECT * FROM books WHERE (title LIKE ? OR author LIKE ?) AND is_archived = ? ORDER BY id DESC";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssi", $search, $search, $show_archived);
        } else {
            $sql = $show_archived 
                ? "SELECT * FROM books WHERE is_archived = 1 OR copies <= 0 ORDER BY id DESC"
                : "SELECT * FROM books WHERE is_archived = 0 AND copies > 0 ORDER BY id DESC";
            $stmt = $conn->prepare($sql);
        }
    }

    if (!isset($stmt)) $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = [];
    while($row = $result->fetch_assoc()) {
        if ($type === 'transactions') {
            $row['display_id'] = (!empty($row['student_id'])) ? $row['student_id'] : ($row['user_id'] ?? 'N/A');
            $row['penalty'] = $row['penalty'] ?? 0;
        }
        $data[] = $row;
    }
    ob_clean();
    echo json_encode($data);

// -------------------------------------------------------------------------
// --- EDIT BOOK (TEXT-ONLY) (PUT) ---
// -------------------------------------------------------------------------
} elseif ($method === 'PUT') {
    $data = json_decode(file_get_contents("php://input"), true);
    
    if (!$data || !isset($data['id'])) {
        ob_clean();
        echo json_encode(["success" => false, "message" => "Missing ID for update."]);
        exit;
    }

    $id = (int)$data['id'];
    $title = trim($data['title'] ?? '');
    $author = trim($data['author'] ?? '');
    $genre = trim($data['genre'] ?? '');
    $subject = trim($data['subject'] ?? '');
    $grade = trim($data['grade'] ?? '');
    $copies = (int)($data['copies'] ?? 0);
    $is_archived = ($copies <= 0) ? 1 : 0;

    $sql = "UPDATE books SET title=?, author=?, genre=?, subject=?, grade=?, copies=?, is_archived=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssiii", $title, $author, $genre, $subject, $grade, $copies, $is_archived, $id);
    
    ob_clean();
    if($stmt->execute()) {
        echo json_encode(["success" => true, "message" => "Book updated successfully"]);
    } else {
        echo json_encode(["success" => false, "message" => $conn->error]);
    }

// -------------------------------------------------------------------------
// --- ADD/UPDATE BOOK WITH IMAGE OR MANAGE TRANSACTIONS (POST) ---
// -------------------------------------------------------------------------
} elseif ($method === 'POST') {
    $action = $_POST['action'] ?? 'add_book';
    
    // --- TRANSACTION MANAGEMENT ACTIONS ---
    if ($action === 'add_transaction') {
        $sid = $_POST['student_id'] ?? '';
        $name = $_POST['borrower_name'] ?? '';
        $bid = $_POST['book_id'] ?? '';
        $due = $_POST['due_date'] ?? '';
        $today = date('Y-m-d');

        // Check stock before adding transaction
        $check = $conn->query("SELECT copies FROM books WHERE id = '$bid' AND is_archived = 0");
        if ($check && $check->num_rows > 0) {
            $book = $check->fetch_assoc();
            if ($book['copies'] > 0) {
                $stmt = $conn->prepare("INSERT INTO transactions (student_id, borrower_name, book_id, borrow_date, due_date, status) VALUES (?, ?, ?, ?, ?, 'active')");
                $stmt->bind_param("sssss", $sid, $name, $bid, $today, $due);
                if($stmt->execute()) {
                    $conn->query("UPDATE books SET copies = copies - 1 WHERE id = '$bid'");
                    ob_clean();
                    echo json_encode(["success" => true, "message" => "Borrowed successfully"]);
                }
            } else {
                ob_clean(); echo json_encode(["success" => false, "message" => "Out of stock"]);
            }
        } else {
            ob_clean(); echo json_encode(["success" => false, "message" => "Invalid Book ID"]);
        }
        exit;
    }

    if ($action === 'return_book') {
        $tid = $_POST['id'];
        $penalty = $_POST['penalty_amount'] ?? 0;
        $r_date = date('Y-m-d');

        $find = $conn->query("SELECT book_id FROM transactions WHERE id = '$tid'");
        $txn = $find->fetch_assoc();
        $bid = $txn['book_id'];

        $stmt = $conn->prepare("UPDATE transactions SET status='returned', return_date=?, penalty=? WHERE id=?");
        $stmt->bind_param("sdi", $r_date, $penalty, $tid);
        if($stmt->execute()) {
            $conn->query("UPDATE books SET copies = copies + 1 WHERE id = '$bid'");
            ob_clean();
            echo json_encode(["success" => true, "message" => "Book returned"]);
        }
        exit;
    }

    // --- BOOK INVENTORY ACTIONS ---
    $id = isset($_POST['id']) ? (int)$_POST['id'] : null;
    $title = trim($_POST['title'] ?? '');
    $author = trim($_POST['author'] ?? '');
    $genre = trim($_POST['genre'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $grade = trim($_POST['grade'] ?? '');
    $copies = (int)($_POST['copies'] ?? 0);
    $is_archived = ($copies <= 0) ? 1 : 0;
    $image_url = $_POST['existing_image'] ?? null;

    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $target_dir = "uploads/";
        if (!file_exists($target_dir)) mkdir($target_dir, 0777, true);
        $new_filename = uniqid() . "." . pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_dir . $new_filename)) {
            if ($id && !empty($image_url)) {
                $oldFile = $target_dir . $image_url;
                if (file_exists($oldFile)) unlink($oldFile);
            }
            $image_url = $new_filename;
        }
    }

    if ($id) {
        $sql = "UPDATE books SET title=?, author=?, genre=?, subject=?, grade=?, copies=?, image_url=?, is_archived=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssisii", $title, $author, $genre, $subject, $grade, $copies, $image_url, $is_archived, $id);
        $msg = "Book updated successfully";
    } else {
        $sql = "INSERT INTO books (title, author, genre, subject, grade, copies, status, image_url, is_archived) VALUES (?, ?, ?, ?, ?, ?, 'available', ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssisi", $title, $author, $genre, $subject, $grade, $copies, $image_url, $is_archived);
        $msg = "Book added successfully";
    }
    
    ob_clean();
    if($stmt->execute()) echo json_encode(["success" => true, "message" => $msg]);
    else echo json_encode(["success" => false, "message" => $conn->error]);

// -------------------------------------------------------------------------
// --- DELETE OR ARCHIVE (DELETE) ---
// -------------------------------------------------------------------------
} elseif ($method === 'DELETE') {
    $id = (int)$_GET['id'];
    if (isset($_GET['permanent']) && $_GET['permanent'] == '1') {
        $stmt = $conn->prepare("DELETE FROM books WHERE id = ?");
    } else {
        $status = (isset($_GET['restore']) && $_GET['restore'] == '1') ? 0 : 1;
        $stmt = $conn->prepare("UPDATE books SET is_archived = ? WHERE id = ?");
        $stmt->bind_param("ii", $status, $id);
    }
    
    if(!isset($status)) $stmt->bind_param("i", $id);
    ob_clean();
    if($stmt->execute()) echo json_encode(["success" => true]);
    else echo json_encode(["success" => false, "error" => $conn->error]);
}
?>