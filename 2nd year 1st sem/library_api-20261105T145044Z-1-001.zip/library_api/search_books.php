<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
require_once 'db_config.php';

$search = isset($_GET['query']) ? mysqli_real_escape_string($conn, $_GET['query']) : '';

// Added AND is_archived = 0 to ensure search results only show active books
$sql = "SELECT * FROM books 
        WHERE (title LIKE '%$search%' OR author LIKE '%$search%') 
        AND is_archived = 0";

$result = mysqli_query($conn, $sql);

$books = [];
if ($result) {
    while($row = mysqli_fetch_assoc($result)) {
        $books[] = $row;
    }
}

echo json_encode($books);
?>