<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') exit;

error_reporting(0); 

require_once 'db_config.php'; 

$json = file_get_contents('php://input');
$data = json_decode($json, true);

$student_id = $data['student_id'] ?? ''; 
$password = $data['password'] ?? '';

if (empty($student_id) || empty($password)) {
    echo json_encode(["success" => false, "message" => "Please enter ID and password"]);
    exit;
}

$student_id = mysqli_real_escape_string($conn, $student_id);

$query = "SELECT * FROM users WHERE student_id = '$student_id'";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $user = mysqli_fetch_assoc($result);
    
   
    if ($password === $user['password'] || password_verify($password, $user['password'])) {
        echo json_encode([
            "success" => true,
            "message" => "Login successful",
            "role" => $user['role'],
            "fullname" => $user['fullname'],
            "student_id" => $user['student_id'] 
        ]);
    } else {
        echo json_encode(["success" => false, "message" => "Incorrect password"]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Student ID not found"]);
}
?>