<?php
include 'db_config.php';

/**
 * THE FIX:
 * We select all columns and order by log_time. 
 * This ensures that if a student scans at 4:00 PM and again at 5:00 PM,
 * both will appear as separate rows in your list.
 */
$query = "SELECT * FROM system_logs ORDER BY log_time DESC LIMIT 1";

$logsResult = $conn->query($query);

if ($logsResult && $logsResult->num_rows > 0) {
    while($log = $logsResult->fetch_assoc()) {
        // Format the specific time for this specific scan row
        $formattedDate = date('M d, Y | h:i A', strtotime($log['log_time']));
        
        echo '<div class="log-item">
                <div class="log-info">
                    <strong>' . htmlspecialchars($log['student_name']) . '</strong>
                    <span>
                        ID: ' . $log['student_id'] . ' • ' . $formattedDate . '
                    </span>
                </div>
                <div class="log-badge">' . strtoupper($log['action']) . '</div>
              </div>';
    }
} else {
    echo '<div style="text-align:center; padding: 20px; color:#888;"><p>No scans recorded yet.</p></div>';
}
?>