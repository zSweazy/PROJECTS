<?php
session_start();
require_once 'db_config.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['fullname']);
    $student_id = mysqli_real_escape_string($conn, $_POST['student_id']);
    // Saving as plain text per your request
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm_password']);
    $question = mysqli_real_escape_string($conn, $_POST['security_question']);
    $answer = mysqli_real_escape_string($conn, $_POST['security_answer']);

    if ($password !== $confirm_password) {
        echo "<script>alert('Passwords do not match!');</script>";
    } elseif (strlen($password) < 8) {
        echo "<script>alert('Password must be at least 8 characters');</script>";
    } else {
        $check = mysqli_query($conn, "SELECT * FROM users WHERE student_id = '$student_id'");
        if (mysqli_num_rows($check) > 0) {
            echo "<script>alert('Student ID already registered');</script>";
        } else {
            // Inserting plain text password directly
            $sql = "INSERT INTO users (fullname, student_id, password, role, security_question, security_answer) 
                    VALUES ('$name', '$student_id', '$password', 'student', '$question', '$answer')";
            if (mysqli_query($conn, $sql)) {
                echo "<script>alert('Account created successfully!'); window.location.href='index.php';</script>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Library System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --admin-navy: #1D3567;
            --bg-color: #DDE6ED;
            --outline-blue: #a3c1da;
        }

        body {
            margin: 0;
            font-family: 'Segoe UI', Roboto, sans-serif;
            background-color: var(--bg-color);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }

        .signup-card {
            width: 450px;
            background: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            text-align: center;
            box-sizing: border-box;
        }

        @keyframes flutterSlideUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .animated-item {
            opacity: 0;
            animation: flutterSlideUp 0.7s cubic-bezier(0.215, 0.61, 0.355, 1) forwards;
        }

        .input-field {
            position: relative;
            margin-top: 25px;
            text-align: left;
        }

        input, select {
            width: 100%;
            padding: 15px 45px 15px 40px; /* Right padding increased for eye icon */
            border: 1px solid #BDBDBD;
            border-radius: 8px;
            font-size: 14px;
            box-sizing: border-box;
            outline: none;
            background: transparent;
            transition: border-color 0.2s;
        }

        .input-field label {
            position: absolute;
            left: 40px;
            top: 50%;
            transform: translateY(-50%);
            background: white;
            padding: 0 5px;
            color: #757575;
            font-size: 14px;
            pointer-events: none;
            transition: 0.2s ease all;
        }

        .input-field i.prefix {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #757575;
        }

        /* View Password Toggle Styling */
        .toggle-password {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #757575;
            z-index: 10;
        }

        input:focus + label,
        input:not(:placeholder-shown) + label {
            top: 0;
            font-size: 12px;
            color: var(--outline-blue);
            left: 10px;
        }

        input:focus { border: 1.5px solid var(--outline-blue); }

        .divider { margin: 25px 0 15px; border-bottom: 1px solid #eee; }
        .recovery-title { color: grey; font-size: 14px; font-weight: bold; margin-bottom: 10px; display: block; }

        .register-btn {
            background-color: var(--admin-navy);
            color: white;
            border: none;
            width: 100%;
            height: 55px;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 25px;
        }

        .footer-link { margin-top: 15px; display: block; color: var(--admin-navy); text-decoration: none; font-size: 14px; }
    </style>
</head>
<body>

<div class="signup-card">
    <form method="POST" autocomplete="off">
        <div class="animated-item" style="animation-delay: 0.4s;">
            <img src="image/logo.png" alt="Logo" style="height: 80px;">
        </div>

        <div class="animated-item" style="animation-delay: 0.5s;">
            <div style="font-size: 22px; font-weight: bold; color: var(--admin-navy); margin-top:10px;">SIGN UP</div>
        </div>

        <div class="animated-item input-field" style="animation-delay: 0.6s; margin-top: 30px;">
            <i class="fas fa-user prefix"></i>
            <input type="text" name="fullname" placeholder=" " required>
            <label>Full Name</label>
        </div>

        <div class="animated-item input-field" style="animation-delay: 0.7s;">
            <i class="fas fa-id-badge prefix"></i>
            <input type="text" name="student_id" placeholder=" " required>
            <label>Student ID</label>
        </div>

        <div class="animated-item input-field" style="animation-delay: 0.8s;">
            <i class="fas fa-lock prefix"></i>
            <input type="password" name="password" id="password" placeholder=" " required>
            <label>Password</label>
            <i class="fas fa-eye toggle-password" onclick="toggleVisibility('password', this)"></i>
        </div>

        <div class="animated-item input-field" style="animation-delay: 0.9s;">
            <i class="fas fa-lock prefix"></i>
            <input type="password" name="confirm_password" id="confirm_password" placeholder=" " required>
            <label>Confirm Password</label>
            <i class="fas fa-eye toggle-password" onclick="toggleVisibility('confirm_password', this)"></i>
        </div>

        <div class="animated-item divider" style="animation-delay: 1.0s;"></div>
        <span class="animated-item recovery-title" style="animation-delay: 1.1s;">Security Recovery</span>

        <div class="animated-item input-field" style="animation-delay: 1.2s;">
            <i class="fas fa-question-circle prefix"></i>
            <select name="security_question" required>
                <option value="" disabled selected>Select a Security Question</option>
                <option>What is your pet's name?</option>
                <option>What is your mother's maiden name?</option>
                <option>What was the name of your first school?</option>
                <option>In what city were you born?</option>
                <option>What is your favorite book?</option>
            </select>
        </div>

        <div class="animated-item input-field" style="animation-delay: 1.3s;">
            <i class="fas fa-key prefix"></i>
            <input type="text" name="security_answer" placeholder=" " required>
            <label>Your Answer</label>
        </div>

        <button type="submit" class="animated-item register-btn" style="animation-delay: 1.4s;">Register Account</button>
        
        <a href="index.php" class="animated-item footer-link" style="animation-delay: 1.5s;">
            Already have an account? Log In
        </a>
    </form>
</div>

<script>
    function toggleVisibility(id, el) {
        const input = document.getElementById(id);
        if (input.type === "password") {
            input.type = "text";
            el.classList.replace('fa-eye', 'fa-eye-slash');
        } else {
            input.type = "password";
            el.classList.replace('fa-eye-slash', 'fa-eye');
        }
    }
</script>

</body>
</html>