<?php
include 'db_config.php';

// Logic to calculate days late and penalty (₱5.00/day)
function calculatePenalty($dueDate) {
    if (empty($dueDate)) return ['days' => 0, 'penalty' => 0];

    $today = new DateTime('today'); // Sets time to 00:00:00
    $due = new DateTime($dueDate);
    
    if ($today > $due) {
        $interval = $today->diff($due);
        $daysLate = $interval->days;
        $penalty = $daysLate * 5.0;
        return ['days' => $daysLate, 'penalty' => $penalty];
    }
    return ['days' => 0, 'penalty' => 0];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Library System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --admin-navy: #1D3567;
            --sidebar-dark: #002147;
            --bg-gray: #F8F9FC;
            --danger-red: #d32f2f;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background-color: var(--bg-gray); display: flex; height: 100vh; }

        /* Sidebar - Consistent with previous pages */
        .sidebar { width: 260px; background: var(--sidebar-dark); color: white; display: flex; flex-direction: column; align-items: center; padding-top: 50px; flex-shrink: 0; }
        .user-avatar { width: 70px; height: 70px; background: rgba(255,255,255,0.2); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 35px; margin-bottom: 15px; }
        .nav-link { width: 100%; padding: 15px 25px; color: rgba(255,255,255,0.7); text-decoration: none; display: flex; align-items: center; transition: 0.3s; }
        .nav-link i { margin-right: 15px; width: 20px; }
        .nav-link:hover, .nav-link.active { background: rgba(255,255,255,0.1); color: white; }
        .nav-link.active { border-left: 4px solid white; font-weight: bold; }

        /* Main Content */
        .content { flex: 1; padding: 40px; overflow-y: auto; }
        .system-title { color: var(--sidebar-dark); font-size: 28px; font-weight: 800; margin-bottom: 5px; }
        .sub-text { color: #666; margin-bottom: 30px; }
        .section-label { color: var(--sidebar-dark); font-size: 18px; font-weight: 700; margin-bottom: 20px; text-transform: uppercase; }

        /* Table Card */
        .report-card { background: white; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.08); overflow: hidden; }
        table { width: 100%; border-collapse: collapse; }
        th { background: var(--sidebar-dark); color: white; padding: 18px; text-align: left; font-size: 14px; text-transform: uppercase; }
        td { padding: 18px; border-bottom: 1px solid #eee; font-size: 14px; color: #444; }
        
        .late-text { color: var(--danger-red); font-weight: 700; }
        .no-data { padding: 50px; text-align: center; color: #888; font-style: italic; }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="user-avatar"><i class="fas fa-user"></i></div>
        <p style="font-weight: 700;">ADMIN</p>
        <p style="font-size: 12px; color: rgba(255,255,255,0.5); margin-bottom: 30px;">Librarian</p>
        
        <a href="admin_dashboard.php" class="nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="inventory.php" class="nav-link"><i class="fas fa-boxes"></i> Inventory</a>
        <a href="transactions.php" class="nav-link"><i class="fas fa-exchange-alt"></i> Transactions</a>
        <a href="reports_page.php" class="nav-link active"><i class="fas fa-chart-bar"></i> Reports</a>
        <a href="history_page.php" class="nav-link"><i class="fas fa-history"></i> History</a>
        
        <div style="flex-grow: 1;"></div>
        <a href="logout.php" class="nav-link" style="color: #ff7675;"><i class="fas fa-sign-out-alt"></i> Log out</a>
    </div>

    <div class="content">
        <h1 class="system-title">Library Management System</h1>
        <p class="sub-text">Detailed overview of overdue books and penalties.</p>
        
        <h2 class="section-label">Overdue Reports</h2>

        <div class="report-card">
            <table>
                <thead>
                    <tr>
                        <th>Borrower ID</th>
                        <th>Book ID</th>
                        <th>Borrowed Date</th>
                        <th>Due Date</th>
                        <th>Days Late</th>
                        <th>Penalty</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Fetch only active/borrowed transactions. 
                    // Includes 'active' and records with blank status as per your DB dump.
                    $query = "SELECT * FROM transactions WHERE status != 'returned'";
                    $result = $conn->query($query);
                    $hasOverdue = false;

                    if ($result && $result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            $calc = calculatePenalty($row['due_date']);
                            
                            // Only display if it's actually late
                            if ($calc['days'] > 0) {
                                $hasOverdue = true;
                                $borrowerID = !empty($row['student_id']) ? $row['student_id'] : $row['user_id'];
                                ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($borrowerID); ?></strong></td>
                                    <td><?php echo $row['book_id']; ?></td>
                                    <td><?php echo $row['borrow_date']; ?></td>
                                    <td><?php echo $row['due_date']; ?></td>
                                    <td class="late-text"><?php echo $calc['days']; ?> Days</td>
                                    <td class="late-text">₱<?php echo number_format($calc['penalty'], 2); ?></td>
                                </tr>
                                <?php
                            }
                        }
                    }

                    if (!$hasOverdue) {
                        echo "<tr><td colspan='6' class='no-data'>No overdue items found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>