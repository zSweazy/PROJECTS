<?php
header("Content-Type: application/json");
include 'db_config.php';

$user_id = $_POST['user_id'];
$book_id = $_POST['book_id'];
$borrow_date = date('Y-m-d');
$due_date = date('Y-m-d', strtotime('+14 days'));

mysqli_begin_transaction($conn);

try {
    // record the transaction
  // ... inside your try block in borrow_book.php
$sql1 = "INSERT INTO transactions (student_id, book_id, borrow_date, due_date, status, borrower_name) 
         VALUES ('$user_id', '$book_id', '$borrow_date', '$due_date', 'active', 'Student User')";
    mysqli_query($conn, $sql1);

    // mark the book as borrowed
    $sql2 = "UPDATE books SET status = 'borrowed' WHERE id = '$book_id'";
    mysqli_query($conn, $sql2);

    mysqli_commit($conn);
    echo json_encode(["success" => true, "message" => "Book borrowed! Return by $due_date"]);

} catch (Exception $e) {
    mysqli_rollback($conn);
    echo json_encode(["success" => false, "message" => "Error: " . $e->getMessage()]);
}
?>