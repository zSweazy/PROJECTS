<?php
session_start();
require_once 'db_config.php'; // Ensure this file has your $conn variable

// 1. Determine the Student ID
// If it's the Flutter app, it sends 'student_id' in the URL.
// If it's a web browser, it uses the 'student_id' from the Session.
$studentId = "";
if (isset($_GET['student_id'])) {
    $studentId = mysqli_real_escape_string($conn, $_GET['student_id']);
} elseif (isset($_SESSION['student_id'])) {
    $studentId = $_SESSION['student_id'];
}

// 2. Fetch the Data
// We select returned books and format the dates directly in SQL for consistency
$sql = "SELECT b.title, b.author, 
               DATE_FORMAT(t.borrow_date, '%b %d, %Y') as borrow_date, 
               DATE_FORMAT(t.return_date, '%b %d, %Y') as return_date, 
               t.penalty
        FROM transactions t
        INNER JOIN books b ON t.book_id = b.id 
        WHERE t.student_id = '$studentId' AND t.status = 'returned' 
        ORDER BY t.return_date DESC";

$result = mysqli_query($conn, $sql);

// 3. API Check
// If the request specifically asks for JSON (like your Flutter app), skip the HTML
if (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false || isset($_GET['student_id'])) {
    $rows = array();
    if ($result) {
        while($r = mysqli_fetch_assoc($result)) {
            $rows[] = $r;
        }
    }
    header('Content-Type: application/json');
    echo json_encode($rows);
    exit(); // Stop here so HTML isn't sent to the app
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Borrowed History - CNHS Library</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root { --admin-navy: #1D3567; --bg-light-blue: #DDE6ED; --card-white: #FFFFFF; --success-green: #28a745; }
        body { margin: 0; font-family: 'Segoe UI', sans-serif; background-color: var(--bg-light-blue); padding-bottom: 30px; }
        .app-bar { background-color: var(--admin-navy); color: white; padding: 15px 20px; display: flex; align-items: center; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .app-bar a { color: white; text-decoration: none; margin-right: 15px; font-size: 18px; }
        .container { padding: 20px; max-width: 600px; margin: 0 auto; }
        .history-card { background: var(--card-white); border-radius: 12px; padding: 15px; margin-bottom: 12px; display: flex; align-items: center; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
        .status-icon { font-size: 24px; color: var(--success-green); margin-right: 15px; }
        .book-details { flex: 1; }
        .book-details h3 { margin: 0; font-size: 15px; color: #333; }
        .book-details p { margin: 4px 0 0; font-size: 12px; color: #666; }
        .penalty-text { text-align: right; font-weight: bold; font-size: 14px; }
        .fine-active { color: #d9534f; }
        .fine-none { color: #999; }
    </style>
</head>
<body>
    <div class="app-bar">
        <a href="student_panel.php"><i class="fas fa-arrow-left"></i></a>
        <span>Borrowed History</span>
    </div>
    <div class="container">
        <?php if ($result && mysqli_num_rows($result) > 0): ?>
            <?php while($row = mysqli_fetch_assoc($result)): ?>
                <div class="history-card">
                    <div class="status-icon"><i class="fas fa-check-circle"></i></div>
                    <div class="book-details">
                        <h3><?= htmlspecialchars($row['title']) ?></h3>
                        <p>Borrowed: <?= $row['borrow_date'] ?></p>
                        <p>Returned: <strong><?= $row['return_date'] ?></strong></p>
                    </div>
                    <div class="penalty-text">
                        <?php $penalty = (float)$row['penalty']; ?>
                        <span class="<?= $penalty > 0 ? 'fine-active' : 'fine-none' ?>">
                            ₱<?= number_format($penalty, 2) ?>
                        </span>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div style="text-align:center; margin-top:50px; opacity:0.6;">
                <i class="fas fa-history" style="font-size:50px;"></i>
                <p>No returned books found.</p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>