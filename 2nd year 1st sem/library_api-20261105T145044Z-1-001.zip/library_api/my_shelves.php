<?php
session_start();
require_once 'db_config.php';

// 1. SESSION CHECK
if (!isset($_SESSION['student_id'])) {
    header("Location: index.php");
    exit();
}

$studentId = $_SESSION['student_id'];
$DAILY_PENALTY_RATE = 5.00; 

// 2. FETCH BORROWED BOOKS
// FIX 1: LEFT JOIN ensures transactions show up even if book info is missing.
// FIX 2: Correct status filter for your DB.
$sql = "SELECT b.title, b.author, b.image_url, t.due_date, t.book_id
        FROM transactions t 
        LEFT JOIN books b ON t.book_id = b.id 
        WHERE t.student_id = ? 
        AND (t.status = 'borrowed' OR t.status = 'Active' OR t.status = '' OR t.status IS NULL)
        ORDER BY t.borrow_date DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $studentId);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Shelves - CNHS Library</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --admin-navy: #1D3567;
            --bg-light: #F0F4F8;
            --red-accent: #E74C3C;
            --green-accent: #27AE60;
        }

        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: var(--bg-light);
            color: #333;
        }

        .app-bar {
            background-color: var(--admin-navy);
            color: white;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .app-bar a { color: white; text-decoration: none; margin-right: 20px; }
        .app-bar h2 { margin: 0; font-size: 18px; flex-grow: 1; font-weight: bold; text-align: center; }

        .container { padding: 16px; max-width: 500px; margin: auto; }

        .book-card {
            display: flex;
            background: white;
            border-radius: 15px;
            margin-bottom: 16px;
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
            min-height: 130px;
        }
        
        .book-card.overdue { border: 1.5px solid var(--red-accent); }

        .cover-section {
            width: 90px;
            background: #f1f1f1;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .cover-section img { width: 90px; height: 130px; object-fit: cover; }

        .details-section {
            padding: 12px;
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .book-title { font-weight: bold; font-size: 14px; text-transform: uppercase; color: #2d3748; }
        .book-author { color: #888; font-size: 12px; margin-bottom: 10px; }

        .info-row { display: flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 600; margin-bottom: 4px; }
        .due-date { color: #555; }
        .penalty-amount { color: var(--red-accent); }

        .status-badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 10px;
            font-weight: bold;
            margin-top: 6px;
            width: fit-content;
        }
        .status-on-time { background: rgba(39, 174, 96, 0.1); color: var(--green-accent); }
        .status-overdue { background: rgba(231, 76, 60, 0.1); color: var(--red-accent); }

        .empty-state { text-align: center; margin-top: 100px; color: var(--admin-navy); opacity: 0.6; }
    </style>
</head>
<body>

    <div class="app-bar">
        <a href="student_panel.php"><i class="fas fa-arrow-left"></i></a>
        <h2>MY SHELVES</h2>
        <i class="fas fa-sync-alt" onclick="location.reload()" style="cursor:pointer;"></i>
    </div>

    <div class="container">
        <?php 
        if ($result->num_rows > 0) {
            while($book = $result->fetch_assoc()) {
                // Calculate Overdue Status and Penalties
                $dueDateTs = strtotime($book['due_date']);
                $todayTs = strtotime(date("Y-m-d"));
                $isOverdue = $todayTs > $dueDateTs;
                
                $penalty = 0;
                if ($isOverdue) {
                    $daysDiff = floor(($todayTs - $dueDateTs) / 86400);
                    $penalty = $daysDiff * $DAILY_PENALTY_RATE;
                }

                // FIX 3: BULLETPROOF IMAGE PATH LOGIC
                // This logic intelligently handles whether the DB saves "image.jpg" or "uploads/image.jpg"
                $dbImage = $book['image_url'];
                $displayImg = ""; // Default to blank

                if (!empty($dbImage)) {
                    if (file_exists($dbImage)) {
                        // DB already has full path like "uploads/image.jpg"
                        $displayImg = $dbImage;
                    } else if (file_exists("uploads/" . $dbImage)) {
                        // DB only has filename, needs prefix
                        $displayImg = "uploads/" . $dbImage;
                    }
                }
                
                // Fallback for missing book data (due to LEFT JOIN)
                $displayTitle = !empty($book['title']) ? $book['title'] : "Unknown Book (ID: " . $book['book_id'] . ")";
                $displayAuthor = !empty($book['author']) ? $book['author'] : "Unknown Author";
                ?>

                <div class="book-card <?= $isOverdue ? 'overdue' : '' ?>">
                    <div class="cover-section">
                        <?php if(!empty($displayImg)): ?>
                            <img src="<?= $displayImg ?>" alt="Book Cover">
                        <?php else: ?>
                            <i class="fas fa-book" style="color:#ccc; font-size: 30px;"></i>
                        <?php endif; ?>
                    </div>
                    
                    <div class="details-section">
                        <div class="book-title"><?= htmlspecialchars($displayTitle) ?></div>
                        <div class="book-author">by <?= htmlspecialchars($displayAuthor) ?></div>
                        
                        <div class="info-row due-date" style="color: <?= $isOverdue ? 'var(--red-accent)' : 'inherit' ?>;">
                            <i class="far fa-calendar-check"></i> Due: <?= date("M d, Y", $dueDateTs) ?>
                        </div>

                        <?php if($penalty > 0): ?>
                            <div class="info-row penalty-amount">
                                <i class="fas fa-hand-holding-usd"></i> Penalty: ₱<?= number_format($penalty, 2) ?>
                            </div>
                        <?php endif; ?>

                        <div class="status-badge <?= $isOverdue ? 'status-overdue' : 'status-on-time' ?>">
                            <?= $isOverdue ? 'OVERDUE' : 'BORROWED' ?>
                        </div>
                    </div>
                </div>

                <?php
            }
        } else {
            ?>
            <div class="empty-state">
                <i class="fas fa-book-reader" style="font-size: 50px;"></i>
                <h3>No borrowed books found</h3>
                <p>Checked Student ID: <strong><?= htmlspecialchars($studentId) ?></strong></p>
            </div>
            <?php
        }
        ?>
    </div>

</body>
</html>