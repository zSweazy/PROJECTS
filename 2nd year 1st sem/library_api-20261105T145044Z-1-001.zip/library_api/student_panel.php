<?php
session_start();
require_once 'db_config.php';

// Check if user is logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: index.php");
    exit();
}

$studentName = $_SESSION['fullname'] ?? "Student";
$studentId = $_SESSION['student_id'];

// Fetch books: Filter out archived and out-of-stock
$sql = "SELECT * FROM books WHERE is_archived = 0 AND copies > 0 ORDER BY id DESC";
$result = mysqli_query($conn, $sql);
$allBooks = [];
if ($result) {
    while($row = mysqli_fetch_assoc($result)) {
        $allBooks[] = $row;
    }
}

// Extract unique values for the dropdown filters
$genres = array_filter(array_unique(array_column($allBooks, 'genre')));
$subjects = array_filter(array_unique(array_column($allBooks, 'subject')));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - CNHS Library</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --admin-navy: #1D3567;
            --bg-light-blue: #F1F5F9; 
            --card-blue: #4B66B0;
        }

        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: var(--bg-light-blue);
            /* Essential: padding so the bottom nav doesn't hide the last items */
            padding-bottom: 90px; 
        }

        /* --- Flutter-style AppBar --- */
        .app-bar {
            background-color: var(--admin-navy);
            color: white;
            padding: 12px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 10px rgba(0,0,0,0.15);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .brand { display: flex; align-items: center; gap: 10px; }
        .brand img { height: 35px; border-radius: 5px; }
        .brand span { font-weight: bold; font-size: 12px; letter-spacing: 0.5px; text-transform: uppercase; }
        .logout-btn { color: white; text-decoration: none; font-size: 18px; }

        /* --- Header / Search Section --- */
        .header-section {
            background-color: var(--admin-navy);
            padding: 20px;
            border-radius: 0 0 30px 30px;
            margin-bottom: 10px;
        }
        .welcome-text {
            color: white;
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 15px;
        }
        .search-bar {
            background: white;
            display: flex;
            align-items: center;
            padding: 12px 15px;
            border-radius: 12px;
            margin-bottom: 10px;
        }
        .search-bar input {
            border: none;
            outline: none;
            width: 100%;
            margin-left: 10px;
            font-size: 14px;
        }
        .filter-row { display: flex; gap: 6px; }
        .filter-row select {
            flex: 1;
            padding: 10px 5px;
            border-radius: 10px;
            border: none;
            font-size: 11px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            outline: none;
        }
        .filter-row select option { color: black; }

        /* --- Book Grid --- */
        .section-title {
            padding: 20px 20px 10px;
            font-size: 18px;
            font-weight: bold;
            color: var(--admin-navy);
        }

        .book-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            padding: 10px 20px;
        }

        .book-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            display: flex;
            flex-direction: column;
            text-decoration: none;
            color: inherit;
            transition: transform 0.2s;
        }
        .book-card:active { transform: scale(0.97); }

        .book-cover {
            aspect-ratio: 3/4;
            background-color: #f0f0f0;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }
        .book-cover img { width: 100%; height: 100%; object-fit: cover; }
        .book-cover i { font-size: 40px; color: #ccc; }

        .book-info { padding: 10px; text-align: center; }
        .book-title { font-weight: bold; font-size: 13px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .book-author { color: grey; font-size: 11px; margin-top: 2px; }
        .grade-badge {
            display: inline-block;
            background: rgba(29, 53, 103, 0.1);
            color: var(--admin-navy);
            font-size: 10px;
            font-weight: bold;
            padding: 3px 8px;
            border-radius: 6px;
            margin-top: 8px;
        }

        /* --- FIXED BOTTOM NAVIGATION --- */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            height: 70px;
            background-color: white;
            display: flex;
            justify-content: space-around;
            align-items: center;
            box-shadow: 0 -2px 15px rgba(0,0,0,0.1);
            z-index: 2000;
        }
        .nav-item {
            text-decoration: none;
            color: #94a3b8;
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 11px;
            font-weight: 500;
        }
        .nav-item i { font-size: 22px; margin-bottom: 4px; }
        .nav-item.active { color: var(--admin-navy); }

        @media (min-width: 768px) {
            .book-grid { grid-template-columns: repeat(4, 1fr); }
        }
    </style>
</head>
<body>

    <div class="app-bar">
        <div class="brand">
            <img src="image/logo.png" alt="Logo" onerror="this.src='https://via.placeholder.com/35'">
            <span>CNHS Library</span>
        </div>
        <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
    </div>

    <div class="header-section">
        <div class="welcome-text">Hello, <?= htmlspecialchars($studentName) ?>!</div>
        <div class="search-bar">
            <i class="fas fa-search" style="color: var(--admin-navy);"></i>
            <input type="text" id="searchInput" placeholder="Search by title or author..." onkeyup="filterBooks()">
        </div>
        <div class="filter-row">
            <select id="genreFilter" onchange="filterBooks()">
                <option value="">Genre</option>
                <?php foreach($genres as $g): ?>
                    <option value="<?= htmlspecialchars($g) ?>"><?= htmlspecialchars($g) ?></option>
                <?php endforeach; ?>
            </select>
            <select id="subjectFilter" onchange="filterBooks()">
                <option value="">Subject</option>
                <?php foreach($subjects as $s): ?>
                    <option value="<?= htmlspecialchars($s) ?>"><?= htmlspecialchars($s) ?></option>
                <?php endforeach; ?>
            </select>
            <select id="gradeFilter" onchange="filterBooks()">
                <option value="">Grade</option>
                <?php for($i=7; $i<=12; $i++): ?>
                    <option value="<?= $i ?>"><?= $i ?></option>
                <?php endfor; ?>
            </select>
        </div>
    </div>

    <div class="section-title">Latest Releases</div>

    <div class="book-grid" id="bookContainer">
        <?php if(empty($allBooks)): ?>
            <p style="grid-column: span 2; text-align: center; color: var(--admin-navy); padding-top: 20px;">No books available.</p>
        <?php else: ?>
            <?php foreach($allBooks as $book): ?>
            <div class="book-card" 
                 data-title="<?= strtolower($book['title']) ?>" 
                 data-author="<?= strtolower($book['author']) ?>"
                 data-genre="<?= htmlspecialchars($book['genre']) ?>"
                 data-subject="<?= htmlspecialchars($book['subject']) ?>"
                 data-grade="<?= htmlspecialchars($book['grade']) ?>">
                <div class="book-cover">
                    <?php 
                    $img = !empty($book['image_url']) ? "uploads/".$book['image_url'] : ""; 
                    if ($img && file_exists($img)): ?>
                        <img src="<?= $img ?>" alt="Cover" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                        <i class="fas fa-book" style="display:none;"></i>
                    <?php else: ?>
                        <i class="fas fa-book"></i>
                    <?php endif; ?>
                </div>
                <div class="book-info">
                    <div class="book-title"><?= htmlspecialchars($book['title']) ?></div>
                    <div class="book-author"><?= htmlspecialchars($book['author']) ?></div>
                    <div class="grade-badge">Grade <?= htmlspecialchars($book['grade']) ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <nav class="bottom-nav">
        <a href="dashboard.php" class="nav-item active">
            <i class="fas fa-home"></i>
            <span>Home</span>
        </a>
        <a href="my_shelves.php" class="nav-item">
            <i class="fas fa-book-bookmark"></i>
            <span>Shelves</span>
        </a>
        <a href="history.php" class="nav-item">
            <i class="fas fa-history"></i>
            <span>History</span>
        </a>
        <a href="account.php" class="nav-item">
            <i class="fas fa-user-circle"></i>
            <span>Account</span>
        </a>
    </nav>

    <script>
        function filterBooks() {
            const query = document.getElementById('searchInput').value.toLowerCase();
            const genre = document.getElementById('genreFilter').value;
            const subject = document.getElementById('subjectFilter').value;
            const grade = document.getElementById('gradeFilter').value;
            
            const cards = document.querySelectorAll('.book-card');
            
            cards.forEach(card => {
                const titleAttr = card.getAttribute('data-title') || "";
                const authorAttr = card.getAttribute('data-author') || "";
                const matchesSearch = titleAttr.includes(query) || authorAttr.includes(query);
                
                const matchesGenre = genre === "" || card.getAttribute('data-genre') === genre;
                const matchesSubject = subject === "" || card.getAttribute('data-subject') === subject;
                const matchesGrade = grade === "" || card.getAttribute('data-grade') === grade;

                if (matchesSearch && matchesGenre && matchesSubject && matchesGrade) {
                    card.style.display = "flex";
                } else {
                    card.style.display = "none";
                }
            });
        }
    </script>
</body>
</html>