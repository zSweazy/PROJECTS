<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

$host = "localhost";
$user = "root";
$pass = "";
$db   = "library_db";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Connection failed"]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $studentId = isset($_GET['student_id']) ? $conn->real_escape_string($_GET['student_id']) : null;

    // UPDATED SQL: Joined with 'books' table to get the 'title' field
    // We use t.* to get transaction details and b.title to get the book name
    $sql = "SELECT t.*, b.title, COALESCE(t.student_id, t.user_id, 'N/A') AS display_id 
            FROM transactions t
            INNER JOIN books b ON t.book_id = b.id
            WHERE t.status = 'returned'";

    if ($studentId !== null && $studentId !== '') {
        $sql .= " AND (t.student_id = '$studentId' OR t.user_id = '$studentId')";
    }

    $sql .= " ORDER BY t.return_date DESC";
    
    $result = $conn->query($sql);
    $data = [];
    
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            // Standardize date formatting for Flutter
            $row['borrow_date'] = date('M d, Y', strtotime($row['borrow_date']));
            $row['return_date'] = date('M d, Y', strtotime($row['return_date']));
            $row['penalty'] = $row['penalty'] ?? "0.00";
            
            $data[] = $row;
        }
        echo json_encode($data);
    } else {
        http_response_code(500);
        echo json_encode(["success" => false, "message" => $conn->error]);
    }
}

$conn->close();
?>