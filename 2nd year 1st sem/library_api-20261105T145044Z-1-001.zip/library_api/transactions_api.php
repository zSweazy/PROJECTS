<?php
// 1. UNIVERSAL CONNECTION & CORS HEADERS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

// HANDLE PRE-FLIGHT FOR FLUTTER/WEB
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// 2. DATABASE CONNECTION
$conn = new mysqli("localhost", "root", "", "library_db");

if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Connection failed"]));
}

$method = $_SERVER['REQUEST_METHOD'];

// --- GET: FETCH TRANSACTIONS ---
if ($method == 'GET') {
    $type = $_GET['type'] ?? 'active'; 
    $student_id = $_GET['student_id'] ?? null;

    if ($student_id) {
        // FETCH FOR SPECIFIC STUDENT (My Shelves)
        // JOIN with books table to get image_url, title, and author
        $stmt = $conn->prepare("SELECT t.*, b.title, b.author, b.image_url 
                                FROM transactions t 
                                LEFT JOIN books b ON t.book_id = b.id 
                                WHERE t.student_id = ? AND (t.status != 'returned' OR t.status IS NULL)
                                ORDER BY t.borrow_date DESC");
        $stmt->bind_param("s", $student_id);
        $stmt->execute();
        $result = $stmt->get_result();
    } 
    else if ($type === 'history') {
        // Show returned books for Admin History (Includes book details)
        $result = $conn->query("SELECT t.*, b.title, b.author, b.image_url 
                                FROM transactions t 
                                LEFT JOIN books b ON t.book_id = b.id 
                                WHERE t.status = 'returned' 
                                ORDER BY t.return_date DESC");
    } else {
        // Show borrowed books for Admin Management (Includes book details)
        $result = $conn->query("SELECT t.*, b.title, b.author, b.image_url 
                                FROM transactions t 
                                LEFT JOIN books b ON t.book_id = b.id 
                                WHERE t.status IN ('borrowed', 'active', 'overdue', '', NULL) 
                                ORDER BY t.id DESC");
    }

    $data = [];
    while($row = $result->fetch_assoc()) { 
        // Flutter compatibility for ID display
        $row['display_id'] = (!empty($row['student_id'])) ? $row['student_id'] : ($row['user_id'] ?? 'N/A');
        
        // Fallback for missing book details
        if (isset($row['book_id'])) {
            $row['title'] = $row['title'] ?? "Unknown Book (ID: ".$row['book_id'].")";
            $row['author'] = $row['author'] ?? "N/A";
            $row['image_url'] = $row['image_url'] ?? ""; // Ensure image_url is at least an empty string
        }
        
        $row['penalty'] = $row['penalty'] ?? 0;
        $data[] = $row; 
    }
    echo json_encode($data);
} 

// --- POST: ADD, UPDATE, RETURN ---
else if ($method == 'POST') {
    $action = $_POST['action'] ?? 'add';
    $id = $_POST['id'] ?? null;
    
    // ACTION: ADD NEW TRANSACTION
    if ($action === 'add') {
        $sid = trim($_POST['student_id'] ?? '');
        $name = $_POST['borrower_name'] ?? '';
        $bid = $_POST['book_id'] ?? '';
        $due = $_POST['due_date'] ?? '';
        $today = date('Y-m-d');

        // Validation: Check if book exists and is not archived
        $checkBook = $conn->query("SELECT copies FROM books WHERE id = '$bid' AND is_archived = 0");
        
        if ($checkBook && $checkBook->num_rows > 0) {
            $book = $checkBook->fetch_assoc();
            
            if ($book['copies'] > 0) {
                $stmt = $conn->prepare("INSERT INTO transactions (student_id, borrower_name, book_id, borrow_date, due_date, status) VALUES (?, ?, ?, ?, ?, 'borrowed')");
                $stmt->bind_param("sssss", $sid, $name, $bid, $today, $due);
                
                if($stmt->execute()) {
                    // Auto-Deduct Inventory
                    $conn->query("UPDATE books SET copies = copies - 1 WHERE id = '$bid'");
                    echo json_encode(["status" => "success", "message" => "Transaction added successfully"]);
                } else {
                    echo json_encode(["status" => "error", "message" => "SQL Error during insert"]);
                }
            } else {
                echo json_encode(["status" => "warning", "message" => "OUT OF STOCK: No copies available"]);
            }
        } else {
            echo json_encode(["status" => "warning", "message" => "NO BOOK EXIST: Invalid or Archived Book ID"]);
        }
        exit();
    } 
    
    // ACTION: RETURN BOOK
    else if ($action === 'return' && $id) {
        $r_date = date('Y-m-d');
        $penalty = $_POST['penalty_amount'] ?? 0;

        $findTxn = $conn->query("SELECT book_id FROM transactions WHERE id = '$id'");
        if ($findTxn && $findTxn->num_rows > 0) {
            $txn = $findTxn->fetch_assoc();
            $bookToReturn = $txn['book_id'];

            $stmt = $conn->prepare("UPDATE transactions SET status='returned', return_date=?, penalty=? WHERE id=?");
            $stmt->bind_param("sdi", $r_date, $penalty, $id);

            if($stmt->execute()) {
                // Auto-Restore Inventory
                $conn->query("UPDATE books SET copies = copies + 1 WHERE id = '$bookToReturn'");
                echo json_encode(["status" => "success", "message" => "Book returned successfully"]);
            } else {
                echo json_encode(["status" => "error", "message" => "Update failed"]);
            }
        } else {
            echo json_encode(["status" => "error", "message" => "Record not found"]);
        }
        exit();
    }
    
    // ACTION: UPDATE RECORD
    else if ($action === 'update' && $id) {
        $sid = $_POST['student_id'] ?? '';
        $name = $_POST['borrower_name'] ?? '';
        $bid = $_POST['book_id'] ?? '';
        $due = $_POST['due_date'] ?? '';

        $stmt = $conn->prepare("UPDATE transactions SET student_id=?, borrower_name=?, book_id=?, due_date=? WHERE id=?");
        $stmt->bind_param("ssssi", $sid, $name, $bid, $due, $id);
        
        if($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "Transaction updated"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Update failed"]);
        }
        exit();
    }
}

// --- DELETE: REMOVAL ---
else if ($method == 'DELETE') {
    $id = $_GET['id'] ?? null;
    if ($id) {
        $stmt = $conn->prepare("DELETE FROM transactions WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            echo json_encode(["status" => "success"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Delete failed"]);
        }
    }
}

$conn->close();
?>