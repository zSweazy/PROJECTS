<?php
include 'db_config.php';

header('Content-Type: application/json');

if (isset($_GET['student_id'])) {
    $studentId = $conn->real_escape_string($_GET['student_id']);

    // 1. Find the student's name from your users table
    $userQuery = $conn->query("SELECT fullname FROM users WHERE student_id = '$studentId'");
    
    if ($userQuery && $userQuery->num_rows > 0) {
        $user = $userQuery->fetch_assoc();
        $name = $user['fullname'];

        // 2. Log the scan into the system_logs table we created in Step 1
        $insert = $conn->query("INSERT INTO system_logs (student_id, student_name, action) 
                                VALUES ('$studentId', '$name', 'Library Entry')");

        if ($insert) {
            echo json_encode(["success" => true, "student_name" => $name]);
        } else {
            echo json_encode(["success" => false, "message" => "Database log failed"]);
        }
    } else {
        echo json_encode(["success" => false, "message" => "Student ID not found in system"]);
    }
} else {
    echo json_encode(["success" => false, "message" => "No ID scanned"]);
}
?>