<?php
session_start();
session_unset();
session_destroy();

// Redirects the browser to your login page immediately
header("Location: index.php"); 
exit();
?>