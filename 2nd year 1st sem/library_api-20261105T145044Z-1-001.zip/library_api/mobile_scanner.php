<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>CNHS Library Scanner</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
    <style>
        :root { 
            --school-navy: #1D3567; 
            --school-gold: #FFD700;
            --light-bg: #F0F2F5; 
        }
        
        body { 
            margin: 0; padding: 0; background: var(--light-bg); 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            display: flex; flex-direction: column; align-items: center; 
            min-height: 100vh; 
        }

        .header { 
            background: var(--school-navy); color: white; width: 100%; 
            padding: 15px 0; text-align: center; 
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            border-bottom: 4px solid var(--school-gold);
        }

        .school-logo {
            width: 70px; height: 70px;
            background: white; border-radius: 50%;
            margin: 0 auto 10px; padding: 5px;
            display: flex; align-items: center; justify-content: center;
            overflow: hidden; border: 2px solid var(--school-gold);
        }

        .school-logo img { width: 100%; height: auto; }

        .header h1 { font-size: 18px; margin: 0; letter-spacing: 1px; }
        .header p { font-size: 12px; margin: 5px 0 0; opacity: 0.9; }

        .container {
            width: 92%; max-width: 400px; margin-top: 25px;
            background: white; padding: 25px; border-radius: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08); text-align: center;
        }

        #reader { 
            width: 100%; border-radius: 15px; overflow: hidden; 
            border: 2px dashed #ccc; background: #000;
            margin-bottom: 10px;
        }

        .status-msg { 
            margin: 15px 0; font-size: 16px; color: var(--school-navy); 
            font-weight: 700; min-height: 24px;
        }

        .btn {
            width: 100%; padding: 18px; border: none; border-radius: 15px;
            font-size: 16px; font-weight: bold; cursor: pointer;
            transition: transform 0.2s, background 0.3s;
            display: flex; align-items: center; justify-content: center; gap: 10px;
        }

        .btn:active { transform: scale(0.98); }

        .btn-scan { background: var(--school-navy); color: white; }
        .btn-stop { background: #dc3545; color: white; display: none; }

        .footer-info { margin-top: 20px; font-size: 11px; color: #888; text-transform: uppercase; }
    </style>
</head>
<body>

    <div class="header">
        <div class="school-logo">
            <img src="logo.png" alt="CNHS Logo" onerror="this.src='image/logo.png'">
        </div>
        <h1>CARMEN NATIONAL HIGH SCHOOL</h1>
        <p><i class="fas fa-book"></i> LIBRARY MANAGEMENT SYSTEM</p>
    </div>

    <div class="container">
        <div class="status-msg" id="status">Ready to Scan Student ID</div>
        
        <div id="reader"></div>

        <button class="btn btn-scan" id="startBtn" onclick="startScanner()">
            <i class="fas fa-qrcode"></i> START SCANNING
        </button>
        
        <button class="btn btn-stop" id="stopBtn" onclick="stopScanner()">
            <i class="fas fa-stop-circle"></i> STOP CAMERA
        </button>

        <div class="footer-info">Digital Library Entry System</div>
    </div>

    <script>
    let html5QrCode;
    let isProcessing = false; // Flag to prevent multiple simultaneous requests
    const beep = new Audio("data:audio/wav;base64,UklGRl9vT19XQVZFRm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YTtvT18=");

    async function startScanner() {
        if (isProcessing) return;
        
        const startBtn = document.getElementById('startBtn');
        const stopBtn = document.getElementById('stopBtn');
        const status = document.getElementById('status');

        startBtn.style.display = 'none';
        stopBtn.style.display = 'flex';
        status.innerText = "Initializing Camera...";

        html5QrCode = new Html5Qrcode("reader");
        
        const config = { 
            fps: 15, 
            qrbox: { width: 220, height: 220 },
            aspectRatio: 1.0
        };

        html5QrCode.start(
            { facingMode: "environment" }, 
            config,
            (decodedText) => {
                // If already processing a scan, ignore new triggers
                if (!isProcessing) {
                    isProcessing = true;
                    beep.play();
                    processScan(decodedText);
                }
            }
        ).then(() => {
            status.innerText = "Align QR Code inside the square";
        }).catch(err => {
            status.innerHTML = `<span style="color:red;">Error: Use HTTPS for camera access</span>`;
            stopScanner();
        });
    }

    async function stopScanner() {
        if (html5QrCode && html5QrCode.isScanning) {
            await html5QrCode.stop().catch(err => console.log(err));
            document.getElementById('startBtn').style.display = 'flex';
            document.getElementById('stopBtn').style.display = 'none';
            // Only reset status if we aren't currently showing a welcome message
            if (!isProcessing) {
                document.getElementById('status').innerText = "Scanner Stopped";
            }
        }
    }

    function processScan(id) {
        const status = document.getElementById('status');
        status.innerText = "Processing scan...";

        // Step 1: Immediately stop scanner to prevent duplicates
        stopScanner();

        // Step 2: Log arrival
        fetch('log_arrival.php?student_id=' + id)
        .then(res => res.json())
        .then(data => {
            if(data.success) {
                status.innerHTML = `<span style="color: #28a745;">✔ Welcome, ${data.student_name}!</span>`;
            } else {
                status.innerHTML = `<span style="color: #dc3545;">✘ ${data.message}</span>`;
            }
        })
        .catch(err => {
            status.innerHTML = `<span style="color: #dc3545;">✘ Network Error</span>`;
        })
        .finally(() => {
            // Step 3: Wait 3 seconds, then reset everything for the next student
            setTimeout(() => {
                isProcessing = false;
                status.innerText = "Ready to Scan Student ID";
            }, 3000);
        });
    }
    </script>
</body>
</html>