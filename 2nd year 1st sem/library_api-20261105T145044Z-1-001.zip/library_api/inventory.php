<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carmen National High School - Inventory</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary-blue: #1D3567;
            --sidebar-dark: #002147;
            --bg-light: #F8F9FC;
            --accent-blue: #4E73DF;
            --archive-orange: #F57C00; 
            --border-light: rgba(0,0,0,0.12);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { display: flex; background-color: var(--bg-light); height: 100vh; overflow: hidden; }

        /* --- SIDEBAR --- */
        .sidebar { width: 240px; background-color: var(--sidebar-dark); color: white; display: flex; flex-direction: column; align-items: center; padding-top: 50px; flex-shrink: 0; }
        .avatar-circle { width: 70px; height: 70px; background-color: rgba(255,255,255,0.24); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 15px; }
        .admin-name { font-weight: bold; text-transform: uppercase; margin-bottom: 5px; }
        .admin-role { color: rgba(255,255,255,0.7); font-size: 12px; margin-bottom: 40px; }
        .nav-item { width: 100%; padding: 15px 25px; display: flex; align-items: center; color: rgba(255,255,255,0.54); text-decoration: none; transition: 0.2s; }
        .nav-item i { width: 25px; margin-right: 15px; font-size: 18px; }
        .nav-item.active { background-color: rgba(255,255,255,0.1); color: white; }
        .nav-item.logout { margin-top: auto; color: #ff5252; margin-bottom: 20px; }

        /* --- MAIN CONTENT --- */
        .main-content { flex: 1; padding: 20px 30px; overflow-y: auto; }
        .school-header { font-size: 22px; font-weight: bold; color: var(--primary-blue); margin-bottom: 20px; }

        /* --- FORM & FILTERS --- */
        .form-card { background: white; padding: 20px; border-radius: 8px; border: 1px solid var(--border-light); margin-bottom: 20px; }
        .form-title { color: var(--accent-blue); font-weight: bold; margin-bottom: 15px; }
        .form-row { display: flex; gap: 10px; margin-bottom: 10px; align-items: center; }
        
        .search-wrapper { position: relative; flex: 2; display: flex; align-items: center; }
        .search-wrapper i { position: absolute; left: 12px; color: #666; font-size: 14px; }
        .search-input { padding-left: 35px !important; }

        input, select { padding: 10px; border: 1px solid #ccc; border-radius: 8px; font-size: 14px; flex: 1; outline: none; transition: 0.2s; }
        input:focus, select:focus { border-color: var(--accent-blue); }

        .image-btn { width: 150px; height: 45px; background: #f8f9fa; border: 1px solid rgba(0,0,0,0.26); border-radius: 8px; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 12px; transition: 0.3s; overflow: hidden; padding: 0 5px; }
        .btn-add { background-color: var(--accent-blue); color: white; border: none; padding: 12px 25px; border-radius: 8px; cursor: pointer; font-weight: bold; display: flex; align-items: center; gap: 8px; }
        
        /* --- TABLE --- */
        .table-container { background: white; border-radius: 8px; border: 1px solid var(--border-light); overflow: hidden; }
        table { width: 100%; border-collapse: collapse; }
        
        thead th { background-color: var(--primary-blue); color: white; text-align: left; padding: 15px; font-size: 13px; text-transform: uppercase; transition: 0.3s; }
        .archive-active thead th { background-color: var(--archive-orange); }

        tbody td { padding: 12px 15px; border-bottom: 1px solid #eee; font-size: 14px; color: #333; }
        .book-cover { width: 35px; height: 35px; background: #eee; border-radius: 4px; object-fit: cover; }
        .action-btns i { margin-right: 15px; cursor: pointer; font-size: 18px; }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="avatar-circle"><i class="fas fa-user fa-2x"></i></div>
        <div class="admin-name"><?php echo htmlspecialchars($_GET['adminName'] ?? 'ADMIN'); ?></div>
        <div class="admin-role">Librarian</div>

        <a href="admin_dashboard.php" class="nav-item"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="inventory.php" class="nav-item active"><i class="fas fa-box"></i> Inventory</a>
        <a href="transactions.php" class="nav-item"><i class="fas fa-exchange-alt"></i> Transactions</a>
        <a href="reports_page.php" class="nav-item"><i class="fas fa-chart-bar"></i> Reports</a>
        <a href="history_page.php" class="nav-item"><i class="fas fa-history"></i> History</a>
        
        <a href="login.php" class="nav-item logout"><i class="fas fa-sign-out-alt"></i> Log out</a>
    </div>

    <div class="main-content">
        <div class="school-header">CARMEN NATIONAL HIGH SCHOOL</div>

        <div class="form-card" id="addBookSection">
            <div class="form-title" id="formActionTitle">Add New Book</div>
            <form id="addBookForm">
                <input type="hidden" name="action" id="formAction" value="add">
                <input type="hidden" name="id" id="bookId">
                <input type="hidden" name="existing_image" id="existingImage">

                <div class="form-row">
                    <input type="text" id="title" name="title" placeholder="Book Title" style="flex: 2;" required>
                    
                    <label class="image-btn" id="imgLabel">
                        <i class="fas fa-image" style="margin-right:5px; color:#888;"></i> <span id="imgText">Add Image</span>
                        <input type="file" id="imageInput" name="image" style="display:none;" accept="image/*">
                    </label>

                    <input type="text" list="dynamicGenres" id="genre" name="genre" placeholder="Genre" required>
                    <input type="text" list="dynamicSubjects" id="subject" name="subject" placeholder="Subject" required>
                </div>
                <div class="form-row">
                    <select id="grade" name="grade" style="flex: 1;" required>
                        <option value="">Grade</option>
                        <option value="7">7</option><option value="8">8</option>
                        <option value="9">9</option><option value="10">10</option>
                        <option value="11">11</option><option value="12">12</option>
                    </select>
                    <input type="text" id="author" name="author" placeholder="Author" style="flex: 1;" required>
                    <input type="number" id="copies" name="copies" placeholder="Copies" style="flex: 1;" required min="0">
                    
                    <button type="submit" class="btn-add" id="submitBtn">Add to System</button>
                    <button type="button" class="btn-add" id="cancelEdit" style="background:#666; display:none;" onclick="resetForm()">Cancel</button>
                </div>
            </form>
        </div>

        <div class="form-row" style="margin-bottom: 15px;">
            <div class="search-wrapper">
                <i class="fas fa-search"></i>
                <input type="text" id="search" class="search-input" onkeyup="runFilter()" placeholder="Search Title or Author...">
            </div>
            <select id="filterGenre" onchange="runFilter()"><option>Genre</option></select>
            <select id="filterSubject" onchange="runFilter()"><option>Subject</option></select>
            <select id="filterGrade" onchange="runFilter()">
                <option>Grade</option><option>7</option><option>8</option><option>9</option>
                <option>10</option><option>11</option><option>12</option>
            </select>
            <button id="viewArchiveBtn" onclick="toggleArchive()" class="btn-add" style="background: orange; min-width: 170px;">
                <i class="fas fa-archive"></i> <span id="archiveBtnText">View Archive</span>
            </button>
        </div>

        <div class="table-container" id="tableWrapper">
            <table>
                <thead id="tableHeader">
                    <tr>
                        <th>ID</th><th>COVER</th><th>TITLE</th><th>GENRE</th><th>SUBJECT</th><th>GRADE</th><th>AUTHOR</th><th>COPIES</th><th>ACTIONS</th>
                    </tr>
                </thead>
                <tbody id="bookTableBody"></tbody>
            </table>
        </div>
    </div>

    <datalist id="dynamicGenres"></datalist>
    <datalist id="dynamicSubjects"></datalist>

    <script>
        let allBooks = [];
        let isViewArchived = false;

        document.getElementById('imageInput').onchange = function() {
            if(this.files && this.files[0]) {
                document.getElementById('imgText').innerText = this.files[0].name.substring(0, 10) + "...";
                document.getElementById('imgLabel').style.borderColor = "#4E73DF";
            }
        };

        document.getElementById('addBookForm').onsubmit = async function(e) {
            e.preventDefault();
            const fields = ['title', 'genre', 'subject', 'author', 'copies', 'grade'];
            let isInvalid = false;

            fields.forEach(id => {
                const el = document.getElementById(id);
                if (el.value === "" || el.value === null) {
                    el.style.borderColor = "red";
                    isInvalid = true;
                } else {
                    el.style.borderColor = "#ccc";
                }
            });

            if (isInvalid) {
                alert("Please fill in all fields.");
                return;
            }

            const formData = new FormData(this);
            const action = document.getElementById('formAction').value;

            try {
                const response = await fetch('http://localhost/library_api/inventory_api.php', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();
                
                if (result.status === "success") {
                    alert(action === "update" ? "Update Successful!" : "Added Successfully!");
                    resetForm();
                    await loadBooks(); 
                } else {
                    alert("Error: " + result.message);
                }
            } catch (error) {
                console.error("Submit error:", error);
            }
        };

        function startEdit(book) {
            // Show form if it was hidden by archive view
            document.getElementById('addBookSection').style.display = "block";
            
            document.getElementById('formActionTitle').innerText = "Update Book Details";
            document.getElementById('formAction').value = "update";
            document.getElementById('bookId').value = book.id;
            document.getElementById('existingImage').value = book.image_url;
            
            document.getElementById('title').value = book.title;
            document.getElementById('genre').value = book.genre;
            document.getElementById('subject').value = book.subject;
            document.getElementById('grade').value = book.grade;
            document.getElementById('author').value = book.author;
            document.getElementById('copies').value = book.copies;
            
            document.getElementById('submitBtn').innerText = "Update Book";
            document.getElementById('cancelEdit').style.display = "block";
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        function resetForm() {
            document.getElementById('addBookForm').reset();
            document.getElementById('formActionTitle').innerText = "Add New Book";
            document.getElementById('formAction').value = "add";
            document.getElementById('submitBtn').innerText = "Add to System";
            document.getElementById('cancelEdit').style.display = "none";
            document.getElementById('imgText').innerText = "Add Image";
            document.getElementById('imgLabel').style.borderColor = "rgba(0,0,0,0.26)";
            
            // Re-hide form if we are still in archive view
            if(isViewArchived) {
                document.getElementById('addBookSection').style.display = "none";
            }
        }

        async function loadBooks() {
            try {
                const res = await fetch(`http://localhost/library_api/inventory_api.php?archived=${isViewArchived ? 1 : 0}`);
                allBooks = await res.json();
                updateDropdownFilters(); 
                updateEntryDatalists();   
                runFilter();             
            } catch (e) { console.error("Load error:", e); }
        }

        function updateEntryDatalists() {
            const genreList = document.getElementById('dynamicGenres');
            const subjectList = document.getElementById('dynamicSubjects');
            const uniqueGenres = [...new Set(allBooks.map(b => b.genre).filter(x => x))];
            const uniqueSubjects = [...new Set(allBooks.map(b => b.subject).filter(x => x))];
            genreList.innerHTML = uniqueGenres.map(g => `<option value="${g}">`).join('');
            subjectList.innerHTML = uniqueSubjects.map(s => `<option value="${s}">`).join('');
        }

        function updateDropdownFilters() {
            const genres = ["Genre", ...new Set(allBooks.map(b => b.genre).filter(x => x))];
            const subjects = ["Subject", ...new Set(allBooks.map(b => b.subject).filter(x => x))];
            document.getElementById('filterGenre').innerHTML = genres.map(g => `<option>${g}</option>`).join('');
            document.getElementById('filterSubject').innerHTML = subjects.map(s => `<option>${s}</option>`).join('');
        }

        function runFilter() {
            const query = document.getElementById('search').value.toLowerCase();
            const genre = document.getElementById('filterGenre').value;
            const subject = document.getElementById('filterSubject').value;
            const grade = document.getElementById('filterGrade').value;

            const filtered = allBooks.filter(book => {
                const matchesSearch = (book.title || "").toLowerCase().includes(query) || (book.author || "").toLowerCase().includes(query);
                const matchesGenre = genre === 'Genre' || book.genre === genre;
                const matchesSubject = subject === 'Subject' || book.subject === subject;
                const matchesGrade = grade === 'Grade' || book.grade === grade;
                return matchesSearch && matchesGenre && matchesSubject && matchesGrade;
            });
            renderTable(filtered);
        }

        function renderTable(books) {
            const body = document.getElementById('bookTableBody');
            body.innerHTML = books.map(book => `
                <tr>
                    <td>${book.id}</td>
                    <td><img class="book-cover" src="http://localhost/library_api/uploads/${book.image_url || ''}" onerror="this.src='https://via.placeholder.com/35?text=?'"></td>
                    <td>${book.title}</td>
                    <td>${book.genre}</td>
                    <td>${book.subject}</td>
                    <td>${book.grade}</td>
                    <td>${book.author}</td>
                    <td>${book.copies}</td>
                    <td class="action-btns">
                        ${!isViewArchived ? `<i class="fas fa-edit" style="color: #4E73DF;" onclick='startEdit(${JSON.stringify(book)})'></i>` : ''}
                        <i class="fas ${isViewArchived ? 'fa-undo' : 'fa-archive'}" 
                            style="color: ${isViewArchived ? '#2E7D32' : '#F57C00'};" 
                            title="${isViewArchived ? 'Restore' : 'Archive'}"
                            onclick='onRestoreClick(${JSON.stringify(book)})'></i>
                        ${isViewArchived ? `
                            <i class="fas fa-trash-alt" 
                               style="color: #ff5252;" 
                               title="Delete Permanently"
                               onclick="deleteBookAction(${book.id}, '${book.title}')"></i>
                        ` : ''}
                    </td>
                </tr>
            `).join('');
        }

        // --- MERGED ACTION LOGIC ---
        function onRestoreClick(book) {
            if (isViewArchived) {
                // Check if book has 0 copies for the automatic edit flow
                if (parseInt(book.copies) === 0) {
                    alert("This book is currently out of stock (0 copies). Opening Edit mode so you can update the inventory.");
                    startEdit(book); 
                } else {
                    // Standard restoration if copies > 0
                    archiveRestoreAction(book.id, true, book.title);
                }
            } else {
                // Standard archiving if in active view
                archiveRestoreAction(book.id, false, book.title);
            }
        }

        async function archiveRestoreAction(id, currentlyArchived, title) {
            const action = currentlyArchived ? "restore" : "archive";
            if (confirm(`Are you sure you want to ${action} "${title}"?`)) {
                try {
                    const res = await fetch(`http://localhost/library_api/inventory_api.php?id=${id}&restore=${currentlyArchived ? 1 : 0}`, { 
                        method: 'DELETE' 
                    });
                    if (res.ok) loadBooks();
                } catch(e) { console.error("Archive Error:", e); }
            }
        }

        async function deleteBookAction(id, title) {
            if (confirm(`WARNING: Are you sure you want to PERMANENTLY delete "${title}"?`)) {
                try {
                    const res = await fetch(`http://localhost/library_api/inventory_api.php?id=${id}&permanent=1`, { 
                        method: 'DELETE' 
                    });
                    if (res.ok) loadBooks();
                } catch (e) { console.error("Delete error:", e); }
            }
        }

        function toggleArchive() {
            isViewArchived = !isViewArchived;
            const btn = document.getElementById('viewArchiveBtn');
            const btnText = document.getElementById('archiveBtnText');
            const tableWrapper = document.getElementById('tableWrapper');
            const addBookSection = document.getElementById('addBookSection');

            if (isViewArchived) {
                tableWrapper.classList.add('archive-active');
                btnText.innerText = "Active Inventory";
                btn.style.background = "#1D3567";
                addBookSection.style.display = "none";
            } else {
                tableWrapper.classList.remove('archive-active');
                btnText.innerText = "View Archive";
                btn.style.background = "orange";
                addBookSection.style.display = "block";
            }
            loadBooks();
        }

        window.onload = loadBooks;
    </script>
</body>
</html>