<?php
header("Content-Type: application/json");
include 'db_config.php';

// Added WHERE is_archived = 0 to filter out hidden books
$sql = "SELECT books.*, categories.name as category_name 
        FROM books 
        LEFT JOIN categories ON books.category_id = categories.id
        WHERE books.is_archived = 0"; 

$result = mysqli_query($conn, $sql);
$books = array();

while($row = mysqli_fetch_assoc($result)) {
    $books[] = $row;
}

echo json_encode($books);
?>