<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
include 'db_config.php';

// Get the student_id from the Flutter app request
$student_id = $_GET['student_id'] ?? '';

if (empty($student_id)) {
    echo json_encode([]);
    exit;
}

// Clean the ID to prevent SQL injection
$student_id = mysqli_real_escape_string($conn, $student_id);

/**
 * FETCH ACTIVE TRANSACTIONS
 * Joins books and transactions to show what the student currently has.
 */
$sql = "SELECT 
            b.title, 
            b.author, 
            b.image_url, 
            t.book_id,
            t.borrow_date, 
            t.due_date,
            t.status,
            t.penalty
        FROM transactions t
        INNER JOIN books b ON t.book_id = b.id 
        WHERE t.student_id = '$student_id' 
        AND t.status = 'active' 
        ORDER BY t.due_date ASC"; // Closest due date first

$result = mysqli_query($conn, $sql);
$books = [];

if ($result) {
    while($row = mysqli_fetch_assoc($result)) {
        // Fallback checks for null values
        $row['title'] = $row['title'] ?? 'Unknown Title';
        $row['author'] = $row['author'] ?? 'Unknown Author';
        $row['image_url'] = $row['image_url'] ?? '';
        $row['penalty'] = $row['penalty'] ?? '0.00';
        $books[] = $row;
    }
}

// Send the clean JSON back to Flutter
echo json_encode($books);
?>