<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - Carmen National High School</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --admin-navy: #1D3567;
            --bg-gray: #DDE6ED;
            --success-green: #2E7D32;
            --purple-accent: #5e35b1;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }

        body {
            background-color: var(--bg-gray);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            overflow: hidden;
            position: relative;
        }

        .reset-card {
            width: 380px; 
            background: white;
            padding: 30px 25px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.12);
            text-align: center;
            animation: fadeInUp 0.5s cubic-bezier(0.2, 0.8, 0.2, 1) forwards;
            position: relative;
            z-index: 10;
        }

        .icon-box {
            font-size: 55px; 
            color: var(--admin-navy);
            margin-bottom: 15px;
            display: inline-block;
            animation: float 4s ease-in-out infinite;
        }

        h2 { font-size: 1.2rem; margin-bottom: 20px; color: #333; }

        .input-group {
            position: relative;
            margin-bottom: 22px;
            text-align: left;
        }

        .input-group input {
            width: 100%;
            padding: 14px;
            border: 1px solid #ccc;
            border-radius: 10px;
            font-size: 15px;
            outline: none;
            background: transparent;
        }

        .input-group label {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #777;
            pointer-events: none;
            transition: all 0.2s ease;
            background: white;
            padding: 0 4px;
        }

        .input-group input:focus + label,
        .input-group input:not(:placeholder-shown) + label {
            top: 0;
            font-size: 12px;
            font-weight: 700;
            color: var(--purple-accent);
        }

        .input-group input:focus { border-color: var(--purple-accent); border-width: 2px; }

        .btn {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 50px;
            background: var(--admin-navy);
            color: white;
            font-weight: 700;
            font-size: 15px;
            cursor: pointer;
            transition: 0.2s;
        }

        .btn:hover { background: #152952; }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(15px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-8px); }
        }

        .bg-pulse {
            position: absolute;
            width: 500px; height: 500px;
            background: radial-gradient(circle, rgba(29, 53, 103, 0.06) 0%, transparent 70%);
            border-radius: 50%;
            z-index: -1;
            animation: pulseBg 8s infinite alternate;
        }

        @keyframes pulseBg {
            from { transform: scale(1); opacity: 0.4; }
            to { transform: scale(1.3); opacity: 0.1; }
        }

        #step2 { display: none; }
    </style>
</head>
<body>

    <div class="bg-pulse"></div>

    <div class="reset-card">
        <div class="icon-box"><i class="fas fa-user-shield"></i></div>

        <div id="step1">
            <h2>Find Account</h2>
            <div class="input-group">
                <input type="text" id="student_id" placeholder=" " autocomplete="off">
                <label>Enter Student ID</label>
            </div>
            <button class="btn" id="searchBtn" onclick="lookupUser()">Search</button>
        </div>

        <div id="step2" style="animation: fadeInUp 0.4s forwards;">
            <p id="displayQuestion" style="font-size: 14px; margin-bottom: 15px; font-weight: 600; text-align: left; color: #555;"></p>
            
            <div class="input-group">
                <input type="text" id="answer" placeholder=" ">
                <label>Your Answer</label>
            </div>

            <div class="input-group">
                <input type="password" id="new_password" placeholder=" ">
                <label>New Password</label>
            </div>

            <button class="btn" style="background: var(--success-green);" onclick="handleReset()">Update Password</button>
        </div>
    </div>

    <script>
        // Use the new API file we created earlier
        const API_URL = 'forgot_password_api.php';

        async function lookupUser() {
            const id = document.getElementById('student_id').value.trim();
            if (!id) return;

            const btn = document.getElementById('searchBtn');
            btn.innerText = "Searching...";

            try {
                const res = await fetch(`${API_URL}?action=get_question&id=${id}`);
                const data = await res.json();

                if (data.success) {
                    document.getElementById('step1').style.display = 'none';
                    document.getElementById('displayQuestion').innerText = "Security Question: " + data.question;
                    document.getElementById('step2').style.display = 'block';
                } else {
                    alert(data.message);
                }
            } catch (e) {
                alert("Error connecting to server.");
            } finally {
                btn.innerText = "Search";
            }
        }

        async function handleReset() {
            const id = document.getElementById('student_id').value;
            const ans = document.getElementById('answer').value;
            const pass = document.getElementById('new_password').value;

            if(!ans || !pass) { alert("Please fill all fields"); return; }

            try {
                const res = await fetch(`${API_URL}?action=reset_password`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `id=${id}&answer=${encodeURIComponent(ans)}&new_password=${encodeURIComponent(pass)}`
                });
                
                const data = await res.json();
                
                if (data.success) {
                    alert("Password updated successfully!");
                    window.location.href = "index.php"; 
                } else {
                    alert(data.message);
                }
            } catch (e) {
                alert("Request failed. Check your API connection.");
            }
        }
    </script>
</body>
</html>